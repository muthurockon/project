// to develop a Java program to read line by line and print line by line

//High level stream sample


import java.io.*;

class SequenceLevelDemo
{
	public static void main(String s[]) throws Exception
	{
		
		FileInputStream fis=new FileInputStream(s[0]);
		SequenceInputStream sis=new SequenceInputStream(fis,System.in);
		FileOutputStream fos=new FileOutputStream(s[1]);

		int value=sis.read();
		while(value != -1)
		{
		fos.write(value);
		value=sis.read();
		}

		Runtime rt=Runtime.getRuntime();				
		Process p=rt.exec("C:\\Windows\\notepad.exe " + s[1]);

		fis.close();
		sis.close();
		fos.close();
		
	}
}