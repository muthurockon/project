// to develop a Java program to read byte arrayand write the contends to a file


import java.io.*;

class ByteReadDemo
{
	public static void main(String s[]) throws Exception
	{
		byte b[]="Ezhilan world!!".getBytes();
		ByteArrayInputStream bais=new ByteArrayInputStream(b);
		FileOutputStream fos=new FileOutputStream(s[0]);
		int value=bais.read();
		while (value !=-1)	
		{
			fos.write(value);
			value=bais.read();
		}
		bais.close();
		fos.close();
	}
}