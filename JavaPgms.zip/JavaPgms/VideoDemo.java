// to develop a Java program to play a video file


import java.io.*;

class VideoDemo
{
	public static void main(String s[]) throws Exception
	{
		
		Runtime rt=Runtime.getRuntime();				
		Process p=rt.exec("C:\\Program Files\\Windows Media Player\\wmplayer.exe " + "C:\\Users\\Public\\Videos\\Sample Videos\\Wildlife.wmv");
		
	}
}