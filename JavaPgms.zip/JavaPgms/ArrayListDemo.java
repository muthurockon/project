import java.util.*;

class ArrayListDemo
{
	public static void main(String s[])
	{
		ArrayList al=new ArrayList();
		al.add(12);
		al.add("Ezhil");
		al.add("Hi");
		al.add("7.7");
		al.add("an");
		al.add(true);
		al.add("Ezhil");
		al.add("Hi");
		al.add("7.7");
		al.add("an");
		al.add("AA");
		al.add("BB");
		al.add("CC");
		
		System.out.println(al);

		System.out.println(al.get(12));
	}
}
