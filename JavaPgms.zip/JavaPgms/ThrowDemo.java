class ThrowDemo
{
	public static void main(String s[])
	{
		try
		{
		throw new ArithmeticException();
		}

		catch(ArithmeticException ae)
		{
		System.out.println(ae.getMessage());
		System.out.println("AE");
		}

		catch(ArrayIndexOutOfBoundsException aioobe)
		{
		System.out.println(aioobe.getMessage());
		System.out.println("AIOOBE");
		}

		catch(NumberFormatException nfe)
		{
		System.out.println(nfe.getMessage());
		System.out.println("NFE");
		}

		catch(Exception e)
		{
		System.out.println(e.getMessage());
		}

		finally
		{
		System.out.println("Executed successfully!!");
		}
		
	}
}
		