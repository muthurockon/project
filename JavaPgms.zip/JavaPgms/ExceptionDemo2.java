class ExceptionDemo2
{
	public static void main(String s[])
	{
		try
		{
		int n1=Integer.parseInt(s[0]);
		int n2=Integer.parseInt(s[1]);
		System.out.println("Sum:" + (n1/n2));
		}

		catch(ArithmeticException ae)
		{
		System.out.println(ae.getMessage());
		System.out.println("AE");
		}

		catch(ArrayIndexOutOfBoundsException aioobe)
		{
		System.out.println(aioobe.getMessage());
		System.out.println("AIOOBE");
		}

		catch(NumberFormatException nfe)
		{
		System.out.println(nfe.getMessage());
		System.out.println("NFE");
		}

		catch(Exception e)
		{
		System.out.println(e.getMessage());
		}

		finally
		{
		System.out.println("Executed successfully!!");
		}
		
	}
}
		