class Vehicle	//super class
{
int speed;
	Vehicle()
	{
	speed=10;
	}

	void move()
	{
	System.out.println("vehicle is moving@" + speed);
	}
}

class Car extends Vehicle // sub class
{
	int speed;

	Car()
	{
	speed=20;
	}

	void c_move()
	{
	System.out.println("vehicle is moving@" + speed);
	}
}

class VehicleDemo
{
	public static void main(String s[])
	{
		Car c=new Car();
		c.move();
		c.c_move();
	}
}