// to develop a Java program to read line by line and print line by line

//High level stream sample


import java.io.*;

class HighLevelDemo
{
	public static void main(String s[]) throws Exception
	{
		
		FileInputStream fis=new FileInputStream("s[0]");
		DataInputStream dis=new DataInputStream(fis);

		String value=dis.readLine();
		while(value != Null)
		{
		System.out.println("Line by line value-->" + value);
		value=dis.readLine();
		}
		fis.close();
		dis.close();
	}
}