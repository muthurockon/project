class NegativeNumberException extends Exception
{
}

class ThrowsDemo
{
	public static void main(String s[]) throws Exception
	{
/*		try
		{*/
		int n=Integer.parseInt(s[0]);
		if (n<0)
			throw new NegativeNumberException();
		else
			System.out.println("Input is correct");
/*		}
	
		catch(Exception e)
		{
		e.printStackTrace();
		}*/
	}
}