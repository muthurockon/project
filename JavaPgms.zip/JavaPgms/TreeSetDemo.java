import java.util.*;

class TreeSetDemo
{
	public static void main(String s[])
	{
		TreeSet t=new TreeSet();
	
		t.add("E");
		t.add("Z");
		t.add("H");
		t.add("I");
		t.add("L");
		/*t.add(null);*/
		
		System.out.println(t);

	}
}