import java.util.*;

class StackDemo
{
	public static void main(String v[])
	{
		Stack s=new Stack();
		s.push(12);
		s.push("Ezhil");
		s.push("Hi");
		
		System.out.println(s);

		s.pop();

		System.out.println(s);

		System.out.println(s.peek());

		System.out.println(s);

		System.out.println(s.search("HI"));

		System.out.println(s.search(12));

		System.out.println(s);

		}
}
