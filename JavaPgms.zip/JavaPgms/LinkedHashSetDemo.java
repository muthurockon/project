import java.util.*;

class LinkedHashSetDemo
{
	public static void main(String s[])
	{
		LinkedHashSet h=new LinkedHashSet();

		h.add("E");
		h.add("Z");
		h.add("H");
		h.add("I");
		h.add("L");
		h.add(null);
		
		System.out.println(h);

		System.out.println(h.add("I"));

		System.out.println(h);

	}
}