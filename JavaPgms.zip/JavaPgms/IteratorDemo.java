import java.util.*;

class IteratorDemo
{
	public static void main(String s[])
	{
		ArrayList a=new ArrayList();
		for(int i=1;i<=10;i++)
			a.add(i);   // auto boxing takes place
		
		System.out.println(a);

		Iterator i=a.iterator();

		while (i.hasNext())
		{
		Integer it=(Integer)i.next();
			if (it%2==0)
				System.out.println(it);
			else
			i.remove();
		}
		
		System.out.println(a);
	}
}