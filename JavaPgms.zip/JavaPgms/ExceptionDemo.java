class ExceptionDemo
{
	public static void main(String s[])
	{
		try
		{
		int n1=Integer.parseInt(s[0]);
		int n2=Integer.parseInt(s[1]);
		System.out.println("Sum:" + (n1/n2));
		}
		
		catch(Exception e)
		{
		e.printStackTrace();
		}

		finally
		{
		System.out.println("Executed successfully!!");
		}
	}
}
		