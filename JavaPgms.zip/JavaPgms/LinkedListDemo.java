import java.util.*;

class LinkedListDemo
{
	public static void main(String s[])
	{
		LinkedList ll=new LinkedList();
		ll.add(12);
		ll.add("Ezhil");
		ll.add("Hi");
		ll.add("7.7");
		ll.add("an");
		ll.add(true);
		ll.add("Ezhil");
		ll.add(null);
		ll.add("Hi");
		ll.add("7.7");
		ll.add("an");
		ll.add("AA");
		ll.add("BB");
		ll.add("CC");
		
		System.out.println(ll);

		System.out.println(ll.get(12));
	}
}
