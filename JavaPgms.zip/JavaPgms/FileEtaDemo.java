// to develop a Java program and compute time taken to read a file


import java.io.*;

class FileEtaDemo
{
	public static void main(String s[]) throws Exception
	{
		
		FileInputStream fis=new FileInputStream("C:\\Users\\Public\\Videos\\Sample Videos\\Wildlife.wmv");
		long t1=System.currentTimeMillis();
		
		int value=fis.read();
		while(value != -1)
		{
			value=fis.read();
		}
		
		long t2=System.currentTimeMillis();
		System.out.println("ETA:" + ((t2-t1)/1000));
	}
}