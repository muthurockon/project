import java.util.*;

class VectorEnumDemo
{
	public static void main(String s[])
	{
		Vector v=new Vector(3);
		v.add(10);		//auto boxing v.add(new Integer(10));
		v.add(11);
		v.add(12);
		v.add(13);
		v.add(14);
		/*v.add("E");*/
				
		Enumeration e=v.elements();

		while (e.hasMoreElements())
		{
			Integer i=(Integer)e.nextElement();
			if (i%2==0)
				System.out.println(i);
		}
		
		System.out.println(v);
	}
}