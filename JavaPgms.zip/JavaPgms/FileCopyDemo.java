// to develop a Java program to copy a file data


import java.io.*;

class FileCopyDemo
{
	public static void main(String s[]) throws Exception
	{
		FileInputStream fis=new FileInputStream(s[0]);
		FileOutputStream fos=new FileOutputStream(s[1]);
		int value=fis.read();
		while (value !=-1)	
		{
			fos.write(value);
			value=fis.read();
		}
		fis.close();
		fos.close();
	}
}