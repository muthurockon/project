class MyThread extends Thread
{
	public void run()
	{
	System.out.println(Thread.currentThread().getName() + "-->"
	+ Thread.currentThread().getPriority());	
	}
}

class ThreadPriDemo
{
	public static void main(String s[]) throws Exception
	{

	Thread.currentThread().setPriority(Thread.NORM_PRIORITY);	

	System.out.println(Thread.currentThread().getName() + "-->"
	+ Thread.currentThread().getPriority());	

	MyThread t=new MyThread();
	t.setPriority(Thread.MIN_PRIORITY);
	t.start();

	MyThread t1=new MyThread();
	t1.setPriority(Thread.MAX_PRIORITY);
	t1.start();

	MyThread t2=new MyThread();
	t2.setPriority(7);
	t2.start();

	}
}