import java.util.*;

class ListIteratorDemo
{
	public static void main(String s[])
	{
		LinkedList<String> a=new LinkedList<String>();

		a.add("E");
		a.add("Z");
		a.add("H");
		a.add("I");
		a.add("L");
		a.add(7);
		
		System.out.println(a);

		/* ListIterator i=a.listIterator();

		while (i.hasNext())
		{
		String it=(String)i.next();
			if (it.equals("I"))
			
				i.remove();
			
			else if (it.equals("E"))
			
				i.set("V");
			
			else if (it.equals("Z"))
				i.add("I");
		
		}
		
		System.out.println(a);*/
	}
}