class NegativeNumberException extends Exception
{
}

class CustomExceptionDemo
{
	public static void main(String s[])
	{
		try
		{
		int n=Integer.parseInt(s[0]);
		if (n<0)
			throw new NegativeNumberException();
		else
			System.out.println("Input is correct");
		}
	
		catch(Exception e)
		{
		e.printStackTrace();
		}
	}
}