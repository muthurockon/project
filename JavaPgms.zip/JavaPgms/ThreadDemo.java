class MyThread extends Thread
{
	public void run()
	{
	for(int i=1;i<=100;i++)
	System.out.println(Thread.currentThread().getName());	
	}
}

class ThreadDemo
{
	public static void main(String s[]) throws Exception
	{
	MyThread t=new MyThread();
	t.setName("1stThread");
	t.start();

	MyThread t1=new MyThread();
	t1.setName("\t\t2ndThread");
	t1.start();

	MyThread t2=new MyThread();
	t2.setName("\t\t\t\t3ndThread");
	t2.start();

	}
}