package rest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
@RestController
@RequestMapping("/demo")
public class RestControl {
@Autowired
	RestDao restDao;



@RequestMapping(value="/select",method=RequestMethod.GET)
public List<RestBean> display()
{
	List<RestBean> ls=new ArrayList<RestBean>();
	ls=restDao.select();
	//System.out.println(ls);
	return ls;
}
@RequestMapping(value="/insert",method=RequestMethod.POST)
public String insert(@RequestBody RestBean rb)
{
String a=restDao.insert(rb);
return a;
}
@RequestMapping(value="/put/{id}",method=RequestMethod.PUT)
public String put(@PathVariable(value="id") int id)
{
	String a=restDao.put(id);
	return a;
}
@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
public String delet(@PathVariable(value="id") int id)
{
	String a = restDao.delet(id);
	return a;
}
}
