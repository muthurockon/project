package rest;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

@Component
public class RestDao extends JdbcDaoSupport{
DataSource dataSource;
@Autowired
public RestDao(DataSource dataSource)
{
	this.dataSource=dataSource;
	setDataSource(dataSource);
}

public List<RestBean> select()
{
List<RestBean> ls=getJdbcTemplate().query("select * from StudentMaster",new Object[]{}, new RestRowMapper());
return ls;
}
public String insert(RestBean value)
{
	int a=getJdbcTemplate().update("insert into StudentMaster values(?,?,?)",new Object[]{value.getId(),value.getName(),value.getAge()});
	String result;
	if(a==0)
	result="Type mismatch or some of the fields are not specified";
	else
		result="inserted successfully";
	return result;
}
public String put(int id)
{
	int a=getJdbcTemplate().update("update StudentMaster set id=? where id="+id,new Object[]{123});
	String result;
	if(a==0)
	result="Type mismatch or some of the fields are not specified";
	else
		result="inserted successfully";
	return result;
}
public String delet(int id)
{
	int a = getJdbcTemplate().update("delete from StudentMaster where id="+id, new Object[]{});
	String result;
	if(a==0)
	
	result ="Delete failed. No record found.";
	else
		result = "delete successful";
	return result;
}
}
