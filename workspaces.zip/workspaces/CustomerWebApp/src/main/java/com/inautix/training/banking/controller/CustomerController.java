package com.inautix.training.banking.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.inautix.training.banking.dao.CustomerDAO;
import com.inautix.training.banking.domain.Customer;

@Controller  
public class CustomerController {
	
	@Autowired
	private CustomerDAO customerDao;
	
	
	@RequestMapping("/customerform")  
    public ModelAndView showform(){  
         //command is a reserved request attribute name, now use <form> tag to show object data  
        return new ModelAndView("customerform","command",new Customer());  
    }  

	
    @RequestMapping(value="/save",method = RequestMethod.POST)  
	public ModelAndView createCustomer(@ModelAttribute("customer") Customer customer){
		System.out.println("inside CustomerController createCustomer");
		
		customerDao.createCustomer(customer);
		
		return new ModelAndView("redirect:/viewcustomers");
		
	}
	
    @RequestMapping(value="/editcustomer/{customerId}")  
	public ModelAndView getCustomerDetails(@PathVariable  int customerId){
		
	    Customer customer = null;
	    customer= customerDao.getCustomerDetails(customerId);
		
	    return new ModelAndView("customereditform","command",customer);  
	    
	}
	
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
	public ModelAndView updateCustomer(@ModelAttribute("customer") Customer customer){
		System.out.println("inside customercontroller updateCustomer");
		customerDao.updateCustomer(customer);
		
		return new ModelAndView("redirect:/viewcustomers");  
		
	}
	
	
    @RequestMapping(value="/deletecustomer/{customerId}",method = RequestMethod.GET) 
    public ModelAndView deleteCustomer(@PathVariable int customerId){
		
		customerDao.deleteCustomer(customerId);
		return new ModelAndView("redirect:/viewcustomers");  
		
	}
	
	@RequestMapping("/viewcustomers") 
	public String getAllCustomers(ModelMap model){
		List customerList = null;
		
		
		customerList = customerDao.getAllCustomer();
		
		model.addAttribute("list", customerList);
		return "viewcustomers"; 
		
	}
	
	
		
	

}
