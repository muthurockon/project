package sample;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class TestRest {
@RequestMapping(value="/myString")
 public String getmyString()
 {
	 return "MyString";
	 
 }
}
