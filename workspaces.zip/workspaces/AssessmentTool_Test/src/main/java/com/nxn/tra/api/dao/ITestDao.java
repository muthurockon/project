package com.nxn.tra.api.dao;

import java.util.List;

import com.nxn.tra.api.model.Test;

public interface ITestDao {
	
	public List<Test> getAllTests() throws Exception;
	public Test getTestDetails(String testId) throws Exception;
	public Test createTest(Test testObj) throws Exception;
	public Test updateTest(Test testObj) throws Exception;
	public Test deleteTest(String testId) throws Exception;
	


}
