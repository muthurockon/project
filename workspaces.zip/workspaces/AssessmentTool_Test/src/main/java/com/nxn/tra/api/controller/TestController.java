package com.nxn.tra.api.controller;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.nxn.tra.api.daoimpl.TestDaoImpl;
import com.nxn.tra.api.model.Data;
import com.nxn.tra.api.model.ErrorDetails;
import com.nxn.tra.api.model.MetaData;
import com.nxn.tra.api.model.Response;
import com.nxn.tra.api.model.Test;

///v2/api-docs/
@RestController
@EnableSwagger2


public class TestController {
	
	
	@Autowired
	TestDaoImpl testDaoimpl;
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;
	
	@RequestMapping(value="/tests", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all tests created", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public ResponseEntity<Response> getAllTestDetails()
	{
		
		List<Test> testList;
		try {
			testList = testDaoimpl.getAllTests();

			saveMetaData(true,"Tests loaded","12345");
			saveData(null, testList);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
			//return response;
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	

	@RequestMapping(value="tests/{id}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiParam(name = "id", value =  "Alphanumeric login to the application blah blah blah", required = true)
	@ApiOperation(value = "Get the details of test created", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "test with given testId does not exist",response = Response.class),
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public ResponseEntity<Response> getTestDetails(@ApiParam(name = "id", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("id") String testId)
	{
		Object[] respArr = new Object[2];
		List<Test> testList = new ArrayList<Test>();
		
			
			try {
				if(testId .length() < 6 || testId == null){
					
					saveMetaData(false,"Bad Request","12345");
					errorDetails.setCode("TRA00005");
					errorDetails.setDescription("Database error");
//					saveData(errorDetails, null);
					saveResponse(data,metaData, errorDetails);
					return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
						
				}
				
				Test testObj = testDaoimpl.getTestDetails(testId);
					
				testList.add(testObj);
				
				saveMetaData(true,"Tests loaded","12345");
				saveData(null, testList);
				saveResponse(data,metaData, null);
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				errorDetails.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					errorDetails.setDescription("Bad Request");
				else if( e instanceof DataAccessException)
					errorDetails.setDescription("Database error");
				else
					errorDetails.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","respId12345");
				//saveData(errorDetails, null);
				saveResponse(null,metaData, errorDetails);
				//return response;
				
			}
				
		return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
		
	}
	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
			data.setOutput(testObj);
		
	}
	@ApiParam(name = "testObj", value = "test object", required = true)
	@RequestMapping(value="/tests",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "created a test", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		   
		    @ApiResponse(code = 201, message = "some thing went wrong", response = Response.class),
		    @ApiResponse(code = 404, message = "some thing went wrong", response = Response.class),
		    @ApiResponse(code = 400, message = "Bad Request", response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error", response = Response.class)}
		)
	public Response createTest(@RequestBody Test testObj)
	{
		List<Test> testList = new ArrayList<Test>();
		try{
			
			if(testObj.getTestId() != null && testObj.getTestId().length() ==8){			
			testObj =testDaoimpl.createTest(testObj);			
			testList.add(testObj);			
			saveMetaData(true,"Test Created","14563");
			saveData(null, testList);
			saveResponse(data,metaData, null);
			}
			else
			{
				errorDetails.setCode("00007");
				errorDetails.setDescription("Test not created");
				saveMetaData(false,"Error Occured","14563");
				saveResponse(null,metaData, errorDetails);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();			
			errorDetails.setCode("00005");
			 if (e instanceof DataAccessException)
			   {
			errorDetails.setDescription("Database Error");
			   }
			 else{
				 errorDetails.setDescription(e.getMessage());
			 }
			saveMetaData(false,"Error Occured","14563");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, errorDetails);
			return response;
		}	
		return response;
	}
	@ApiParam(name = "testObj", value = "test object", required = true)
	@RequestMapping(value="/tests",method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Updates a test", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful creation  of test ", response = Response.class),
		    @ApiResponse(code = 404, message = "some thing went wrong",response = Response.class),
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public Response updateTest(@RequestBody Test testObj)
	{
		
		List<Test> testList = new ArrayList<Test>();
		try{
			testObj =testDaoimpl.updateTest(testObj);			
			testList.add(testObj);			
			saveMetaData(true,"Test Updated","123457");
			saveData(null, testList);
			saveResponse(data,metaData,null);
			
		}
		catch(Exception e){
			e.printStackTrace();			
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","123457");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, errorDetails);
			return response;
		}	
		return response;
	}
	
	
	
	@RequestMapping(value="/tests/{id}",method=RequestMethod.DELETE,  produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "deletes the test", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful deletion  of test ", response = Response.class),
		    @ApiResponse(code = 404, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	
	public Response deleteTest(@ApiParam(name = "id", value = "Alphanumeric login to the application blah blah blah", required = true) @PathVariable("id") String testId  )
	{
		List<Test> testList = new ArrayList<Test>();
		try{
			Test testObj =testDaoimpl.deleteTest(testId);			
			testList.add(testObj);			
			saveMetaData(true,"Tests Deleted","24541");
			saveData(null, testList);
			saveResponse(data,metaData, null);
			
		}
		catch(Exception e){
			e.printStackTrace();			
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","24541");
			saveData(errorDetails, null);
			saveResponse(null,metaData,errorDetails);
			return response;
		}	
		return response;
	}
	
	
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	

}
