package com.nxn.tra.api.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel
public class Test 
{
	@ApiModelProperty(position = 1, required = true, value = "testId containing only lowercase letters or numbers")
			private String testId;
	public String getTestCreatedTs() {
		return testCreatedTimeStamp;
	}
	public void setTestCreatedTs(String testCreatedTS) {
		this.testCreatedTimeStamp = testCreatedTimeStamp;
	}
	@ApiModelProperty(position = 2, required = true, value = "testname containing only lowercase letters or numbers")
	private String testName;
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
	public String getTestName() {
		return testName;
	}
	
	public void setTestName(String testName) {
		this.testName = testName;
	}

	
	public String getTestDuration() {
		return testDuration;
	}
	public void setTestDuration(String testDuration) {
		this.testDuration = testDuration;
	}
	
	public String getTestInstr() {
		return testInstr;
	}
	public void setTestInstr(String testInstr) {
		this.testInstr = testInstr;
	}
	public String getTestChargeBack() {
		return testChargeBack;
	}
	public void setTestChargeBack(String testChargeBack) {
		this.testChargeBack = testChargeBack;
	}
	@ApiModelProperty(position = 6, required = false, value = "Test created timestamp is added by the system")
	private String testCreatedTimeStamp;
	@ApiModelProperty(position = 3, required = true, value = "Test Duration containing numbers in mins")
	private String testDuration;
	@ApiModelProperty(position = 4, required = true, value = "Test Duration containing numbers in mins")
	private String testInstr;
	@ApiModelProperty(position = 5, required = true, value = "Test Duration containing numbers in mins")
	private String testChargeBack;
	
	

}
