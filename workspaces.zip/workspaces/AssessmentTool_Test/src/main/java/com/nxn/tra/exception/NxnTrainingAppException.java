package com.nxn.tra.exception;

public class NxnTrainingAppException extends Exception{
	private String msg = null;
	private Exception exception = null;
			
	public NxnTrainingAppException(String msg) {
		this.msg = msg;
	}
	
	public NxnTrainingAppException(String msg, Exception exception) {
		this.msg = msg;
		this.exception = exception;
	}

}
