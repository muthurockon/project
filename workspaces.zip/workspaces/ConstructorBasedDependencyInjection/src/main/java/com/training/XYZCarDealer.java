package com.training;

public class XYZCarDealer implements CarDealer{
	
	private CarCompany carCompany;
	
	
	public XYZCarDealer(CarCompany carCompany){
		
		this.carCompany=carCompany;
	}
	
	
	public void deliverCar(){
		
		carCompany.deliverCar();
		
	}
	

}
