package email;

import java.io.IOException;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("in11");
		String from="";
		String commonMessage="";
		String signature="";
		String path="C:/Users/XBBNH7V/Desktop/email.xlsx";
		String log;
		MailService mailService=new MailService();
		ExcelService csr=new ExcelService ();
		try {
			//System.out.println("in");
			List<MailBean> mailList=csr.readBooksFromExcelFile(path);
			for(MailBean mail: mailList)
			{
				log=mailService.sendMail(mail, from, commonMessage, signature);
				//System.out.println(mail.getToAddress()+" "+mail.getSubject()+" "+mail.getMessage());
				System.out.println(log);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
	}

}
