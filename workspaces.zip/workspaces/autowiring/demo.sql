create schema muthu;
create table demo(id int,name varchar(20));
insert into demo values(101,'mk');
select * from demo;