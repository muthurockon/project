package com.training;

public class Guitar implements Instrument {

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("guitar");

	}

}
