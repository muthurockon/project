package com.training;

import org.springframework.beans.factory.annotation.Autowired;

public class Musician implements Performer {
   @Autowired
	Instrument a;





	public Instrument getA() {
		return a;
	}





	public void setA(Instrument a) {
		this.a = a;
	}





	public void perform() {
		// TODO Auto-generated method stub
    	a.play();

	}

}
