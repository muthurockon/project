package com.training;

public class Flute implements Instrument {

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Flute");

	}

}
