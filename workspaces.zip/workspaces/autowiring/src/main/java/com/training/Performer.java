package com.training;

public interface Performer {
public void perform();
}
