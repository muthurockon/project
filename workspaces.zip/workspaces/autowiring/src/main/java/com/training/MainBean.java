package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;





public class MainBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ApplicationContext ob=new ClassPathXmlApplicationContext("applicationContext.xml");
	Musician a=(Musician) ob.getBean("m");
	a.perform();

	}

}
