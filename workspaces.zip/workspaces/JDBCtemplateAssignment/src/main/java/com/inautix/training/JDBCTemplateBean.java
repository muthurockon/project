package com.inautix.training;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class JDBCTemplateBean {

	private DataSource dataSource;
	private JdbcTemplate t;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.t=new JdbcTemplate(dataSource);
	}

	public void createTable(StudentMaster s)
	{
		String sql="insert into StudentMarksheet values("+s.getId()+",'"+s.getName()+"',"+s.getAge()+")";
		System.out.println("sql"+sql);
		t.update(sql);
	}
	public void update(StudentMaster s)
	{
		String sql="update StudentMarksheet set id="+s.getId()+",age="+s.getAge()+"where name='"+s.getName()+"'";
		System.out.println("sql"+sql);
		t.update(sql);
	}
	public void dispall()
	{
		
		String sql="select * from StudentMarksheet";
		System.out.println("Id\tName\tAge");
		t.query(sql, new Object[]{}, new StudentMapper());
		//return res;
		
	}
	public StudentMaster display(int id)
	{
		
		String sql="select * from StudentMarksheet where id="+id;
		StudentMaster ob=t.queryForObject(sql, new Object[]{}, new StudentMapper());
		return ob;
	}

}
