package com.inautix.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentController {
@Autowired
private JDBCTemplateBean jd;
public void insert(StudentMaster s)
{
	jd.createTable(s);
}
public void disp()
{
	jd.dispall();
}
public void update(StudentMaster s)
{
	jd.update(s);
	
}
public StudentMaster display(int id)
{
	return jd.display(id);
}
}
