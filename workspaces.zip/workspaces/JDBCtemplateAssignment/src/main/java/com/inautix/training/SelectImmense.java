package com.inautix.training;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SelectImmense {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ob = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentController a=(StudentController) ob.getBean("controller");
		StudentMaster x=a.display(1);
		System.out.println(x.getName());
	}

}
