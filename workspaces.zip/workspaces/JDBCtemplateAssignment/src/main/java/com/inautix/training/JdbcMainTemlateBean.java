package com.inautix.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JdbcMainTemlateBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ob = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentController a=(StudentController) ob.getBean("controller");
StudentMaster s=new StudentMaster();
s.setId(10);
s.setName("Gokul");
s.setAge(22);
a.insert(s);
	}

}
