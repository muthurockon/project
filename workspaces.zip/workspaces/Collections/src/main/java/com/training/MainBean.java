package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ob=new ClassPathXmlApplicationContext("applicationContext.xml");
		OneManBand a=(OneManBand) ob.getBean("coll");
		a.perform();

	}

}
