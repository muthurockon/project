package com.training;

import java.util.Collection;



public class OneManBand implements Performer {
private Collection<Instrument> instr;

	

	public Collection<Instrument> getInstr() {
	return instr;
}



public void setInstr(Collection<Instrument> instr) {
	this.instr = instr;
}



	public void perform() {
		// TODO Auto-generated method stub
	for(Instrument a:instr)
	{
		a.play();
	}
	

	}

}
