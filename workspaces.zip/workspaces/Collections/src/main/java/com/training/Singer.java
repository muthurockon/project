package com.training;

public class Singer implements Performer {
String song;


	public Singer(String song) {
	super();
	this.song = song;
}


	public void perform() {
		// TODO Auto-generated method stub
System.out.println(song);
	}

}
