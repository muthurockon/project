package com.training;

public class ABT implements CarDealer{
	
	private CarCompany carCompany;
	
		
	
	public CarCompany getCarCompany() {
		return carCompany;
	}

	public void setCarCompany(CarCompany carCompany) {
		this.carCompany = carCompany;
	}
    public void deliverCar(){
    	System.out.println("from ABT");
    	carCompany.deliverCar();
		
		
	}
	
	

}
