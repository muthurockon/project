package com.training;

public class Instrumentalist{
Flute f;
	public void perform()
{
      f.play();
}
	public Flute getF() {
		return f;
	}
	public void setF(Flute f) {
		this.f = f;
	}
}
