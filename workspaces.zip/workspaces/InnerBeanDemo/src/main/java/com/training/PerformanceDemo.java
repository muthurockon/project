package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PerformanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ob=new ClassPathXmlApplicationContext("applicationContext.xml");
		Singer s=(Singer) ob.getBean("sing");
		s.perform();
		Instrumentalist ins=(Instrumentalist) ob.getBean("ins");
		ins.perform();
	}

}
