package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InnerBeanDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext ob=new ClassPathXmlApplicationContext("applicationContext.xml");
Instrumentalist abc=(Instrumentalist) ob.getBean("ins");
abc.perform();
	}

}
