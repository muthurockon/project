package com.training;

public class Instrumentalist implements Performer {
  Flute s;
  
	public Flute getS() {
	return s;
}

public void setS(Flute s) {
	this.s = s;
}

	public void perform() {
		// TODO Auto-generated method stub
s.play();
     
	}

}
