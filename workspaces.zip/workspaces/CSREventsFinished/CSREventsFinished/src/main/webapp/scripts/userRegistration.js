/**
 * 
 */

var app=angular.module("myApp");        
var place;
app.controller("registerUserController", function ($scope,$window,$http,$filter,insertUser,insertUserDetails) {
	
	$scope.designation= ["TRAINEE", "OTHER"];
    $scope.myClick=function(id,emailId,joiningDate,name,perEmail,phNumber,places){





      var a = $filter('date')(joiningDate, "MM-dd-yyyy");

        var data={
            commitId: id,
      inautixEmail: emailId,
      
      deignation: $scope.selectedDesignation,
      dateOfJoining: a,
          
        };

  var details={
           commitId : id,
           userName : name,
           personalEmail : perEmail,
           phoneNumber : phNumber,
           location : $scope.user.from,

  };
        var jdata = JSON.stringify(data);
        var jdetails=JSON.stringify(details);

                  window.alert(jdata);    
                   window.alert(jdetails); 
              
        
                   insertUser.setUser(jdata).then(function(response){
           
          $scope.message="Inserted Successfully";
          insertUserDetails.setUserDetails(jdetails).then(function(response){
              
              $scope.message="Inserted Successfully";
            
            // $location.path('/user');
           },function(response) {
               window.alert('No users found');
             
           })  
        //  $window.location.href = '/user';
        // $location.path('/user');
       },function(response) {
           window.alert('No users found');
         
       })
          
    }

$scope.user = {'from': '', 'fromLat': '', 'fromLng' : ''};
var options = {
    componentRestrictions: {country: "in"}
};
var inputFrom =document.getElementById('from');

 //document.getElementById('from');
var autocompleteFrom = new google.maps.places.Autocomplete(inputFrom, options);
google.maps.event.addListener(autocompleteFrom, 'place_changed', function() {
	//$window.alert($scope.place_start);
    place = autocompleteFrom.getPlace();
    $scope.user.fromLat = place.geometry.location.lat();
    $scope.user.fromLng = place.geometry.location.lng();
    $scope.user.from = place.address_components[0].long_name;
    $scope.$apply();
});
//end of google
//remaining controller code here





//end of controller   
});
 