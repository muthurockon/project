package com.csr.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.csr.bean.Event;
import com.csr.bean.Place;
import com.csr.bean.User;
import com.csr.dataaccess.EventDAO;
import com.csr.mail.MailService;
import com.csr.model.Data;
import com.csr.model.Error;
import com.csr.model.MetaData;
import com.csr.model.Response;

@EnableSwagger2
@RestController
public class EventController {
	@Autowired
	  EventDAO events;
	   @Autowired
	   MetaData metaData;
	   @Autowired
	   Data data;
	   @Autowired
	   Response response;
	   @Autowired
	   Error error;
	
		@ApiOperation(value="Retrieve all events using GET method",notes="Returns the event data")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
		@RequestMapping(value ="/events" , method = RequestMethod.GET,  produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> getAllRecords() {
			ResponseEntity res=null;
			List<Event> event = new ArrayList<Event>();  
			event=events.getAllEvents();
			if(!event.isEmpty())
			{
				saveMetaData(true,"Details found","1001");
				saveData(null,event);
				saveResponse(data,metaData, null);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
			else
			{
				//Error error=new Error();
				error.setCode("CSR_EVE2001");
				error.setDescription("Result set not found");
				saveMetaData(false,"Error Occured","2001");
				saveResponse(null,metaData,error);
				res=new ResponseEntity(response,HttpStatus.NOT_FOUND);
			}
			return res;
		}
		
		@ApiOperation(value="Create a new event using using POST method",notes="Register a event to send automated emails")
		@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
		@RequestMapping(value="/events",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
     public ResponseEntity<Response> createNewEvent(@RequestBody Event event)
     {	
			 ResponseEntity res=null;
		
         /* System.out.println(bean.getMobile());
          System.out.println(bean.getUserName());
          System.out.println(bean.getPassword());
          System.out.println(bean.getEmail());*/
          int result= events.createEvent(event);
          
          if(result==-1)
          {
         	 error.setCode("CSR_EVE2003");
      		error.setDescription("Unique constraint violated. ID already present");
         	 saveMetaData(false,"Error Occured. Unique constraint violated ","2003");
      		saveResponse(null,metaData,error);
         	 res=new ResponseEntity(response,HttpStatus.CONFLICT);
          }
          else if(result==-2)
			{
				error.setCode("CSR_EVE2011");
       		error.setDescription("Mobile number should have only digits");
       		saveMetaData(false,"Bad argument.Mobile number should have only digits","2011");
       		saveResponse(null,metaData,error);
       		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(result==-3)
			{
				error.setCode("CSR_EVE2012");
       		error.setDescription("Name should have only alphabets");
       		saveMetaData(false,"Bad argument.Name should have only alphabets","2012");
       		saveResponse(null,metaData,error);
       		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
          else if(result==0)
          {
         	 	error.setCode("CSR_EVE2004");
         	 	sendEventDeatilsMail(event);
         		error.setDescription("Enter All Details");
         		saveMetaData(false,"Error Occured. Enter all details","2004");
         		saveResponse(null,metaData,error);
         		res=new ResponseEntity(response,HttpStatus.FORBIDDEN);
          }
          else
          {
        		 System.out.println("Event Controller");
        		 sendEventDeatilsMail(event);
         	 	saveMetaData(true,"The following detail is inserted successfully","1005");
         	 	List<Event> eventList=new ArrayList();
         	 	eventList.add(event);
         	 	saveMetaData(true,"Insert success.The following detail is inserted successfully","1005");
         		saveData(null,eventList);
         		saveResponse(data,metaData, null);
         		res=new ResponseEntity(response,HttpStatus.OK);
          }
         	// response=new ResponseEntity("Insert suuccess",HttpStatus.OK);
          return res;
     }
		@ApiOperation(value="Delete a event using DELETE method",notes="An event can be deleted")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
		@RequestMapping(value="/events/{eventId}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> deleteUser(@ApiParam(value="Enter ID of the user to delete",required=true)@PathVariable(value="eventId") String eventId)
		{
			ResponseEntity resp=null;
			System.out.println("Welcome Delet");
			int eid=Integer.parseInt(eventId);
			int res=events.delete(eid);
			System.out.println("In Delete"+res);
			if(res==-2)
			{
				error.setCode("CSR_PLACE2007");
        		error.setDescription("Mobile number should have only digits");
        		saveMetaData(false,"Bad argument.Mobile number should have only digits","2007");
        		saveResponse(null,metaData,error);
        		resp=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(res==-4)
			{
				error.setCode("CSR_PLACEE2020");
        		error.setDescription("Phone number should be 10 digit long");
        		saveMetaData(false,"Phone number should be 10 digit long","2020");
        		saveResponse(null,metaData,error);
        		resp=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(res==-5)
			{
				error.setCode("CSR_PLACEE2021");      
        		error.setDescription("Enter necessary fields");
        		saveMetaData(false,"Enter necessary fields","2021");
        		saveResponse(null,metaData,error);
        		resp=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(res==1)
			{
				saveMetaData(true,"Delete success. The remaining data after deletion is displayed","1006");
				List<Event> event=new ArrayList();
				event=events.getAllEvents();
				saveData(null,event);
				System.out.println();
				saveResponse(data,metaData, null);
				resp=new ResponseEntity(response,HttpStatus.OK);
			}
				
			else
			{
				 error.setCode("CSR_PLACE2026");
	         		error.setDescription("Record ID to be deleted not found");
	         		saveMetaData(false,"Record ID to be deleted not found","2026");
	         		saveResponse(null,metaData,error);
				resp=new ResponseEntity(response,HttpStatus.NOT_FOUND);
			}
			return resp;
		}
		
		public void sendEventDeatilsMail(Event event)

		{ List<User> userDetails=new ArrayList<User>();
		userDetails=events.getEventByPlaceId(event.getPlaceId());
			MailService mailService=new MailService();
		
			String messageSubject="CSR Place assignment-Regd.";
			String messageText="Hi, \n  There is a event happening at the place you have registered. The event name is "+event.getEventName()+"\n The event is about "+event.getDescription()+".\n For the following Date"+event.getEventDate()+". \n You should be reporting to"+event.getEventLead();
			messageText+=".\nThis message is sent with high importance";
			messageText.replaceAll("\n", System.getProperty("line.separator"));
//			messageText+="Short address is "+place.getLocation();
			try {
				mailService.sendEvent(userDetails, messageSubject, messageText);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(messageText);
		}
		private void saveResponse(Data data, MetaData metaData, Error errorDet) {
			response.setData(data);
			response.setMetaData(metaData);
			response.setError(errorDet);
		}
		private void saveData(Error erroDet, List event) {
			response.setError(erroDet);
			
				data.setOutput(event);
			
		}
		private void saveMetaData(boolean success, String description, String responseId){
			metaData.setSuccess(success);
			metaData.setDescription(description);
			metaData.setResponseId(responseId);
		}
}
