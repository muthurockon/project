create table  T_CSR_Places(placeId INT PRIMARY KEY ,name varchar(30),address varchar(500),loaction varchar(30),contactNumber varchar(11));
create table T_CSR_Events(eventId int,eventName varchar(30),placeId INT,description varchar(500),eventDate Date,eventIncharge varchar(200));
create table T_CSR_USER(commitId varchar(20) primary key,inautixEmail varchar(30),locationAssigned varchar(30),designation varchar(20), dateofjoining date,weeksPending int);
create table T_CSR_USER_DETAIL(commitId varchar(20),userName varchar(30),personalEmail varchar(20),phoneNumber varchar(11),location varchar(30));
create table T_CSR_ATTENDENCE(commitId varchar(20),eventId int,comments varchar(20));

insert into T_CSR_USER('commitId','inautixEmail','designation','dateOfJoining','weeksPending') values('xbbnh7v','muvaidyanathan@inautix.co.in','TRAINEE',to_date('14-06-2017','dd-MM-yyyy'),12);

insert into T_CSR_USER values('xbbnh7v','muvaidyanathan@inautix.co.in',null,'TRAINEE',TO_DATE('2017/06/14','yyyy/mm/dd'),12);
drop table T_csr_user_detail;
insert into T_CSR_USER_DETAIL values('xbbnh7v','muthukumar','muthukumar2482@gmail.com','9840612391','Chennai');
select * from T_csr_user_detail;
insert into T_CSR_ATTENDENCE values('xbbnh7v',TO_DATE('2017/06/24','yyyy/mm/dd'),'littleflower');
delete from T_csr_user_detail;
drop table T_csr_user_detail;
select * from T_CSR_ATTENDENCE;
select * from T_CSR_USER;
select * from T_CSR_user where dateofjoining=to_date('06/14/2017','MM/dd/yyyy');
select T_CSR_USER.commitId,inautixEmail,locationAssigned,designation,dateofjoining,weeksPending,location 
from T_CSR_USER 
inner join T_CSR_USER_DETAIL 
on T_CSR_USER.commitId=T_CSR_USER_DETAIL.commitId
where  dateofjoining=to_date('06/14/2017','MM/dd/yyyy');
ALTER TABLE T_CSR_USER
  MODIFY inautixEmail varchar(100);
  ALTER TABLE T_CSR_USER
  MODIFY inautixEmail varchar(100);