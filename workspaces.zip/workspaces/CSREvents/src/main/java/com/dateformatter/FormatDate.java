package com.dateformatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FormatDate {
	public static java.sql.Date  parse(String dateString) 
	{
		SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
		Date parsed=null;
		try {
			parsed = format.parse(dateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date date = new java.sql.Date(parsed.getTime());
		return date;
	}
}
