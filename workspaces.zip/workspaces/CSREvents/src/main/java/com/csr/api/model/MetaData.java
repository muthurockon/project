package com.csr.api.model;

import io.swagger.annotations.ApiModelProperty;


	
	public class MetaData {
		@ApiModelProperty(position = 2, required = true, value = "what type of eorror or success message to be returned")
		private String description;
		@ApiModelProperty(position = 1, required = true, value = "holds the value of the id to be returned ")
		private String responseId;
		@ApiModelProperty(position = 3, required = true, value = "bollean value for sucess/failure  ")
		private boolean success;
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getResponseId() {
			return responseId;
		}
		public void setResponseId(String responseId) {
			this.responseId = responseId;
		}
		public boolean getSuccess() {
			return success;
		}
		public void setSuccess(boolean success) {
			this.success = success;
		}
		
	}


