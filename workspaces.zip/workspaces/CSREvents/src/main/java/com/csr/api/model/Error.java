package com.csr.api.model;

import io.swagger.annotations.ApiModelProperty;



@SuppressWarnings("restriction")

public class Error {

	@ApiModelProperty(position = 1, required = true, value = "Tra team name + error code ")
	private String code;
		@ApiModelProperty(position = 2, required = true, value = "has he details of the property ")
	private String description;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
