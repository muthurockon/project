package com.csr.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.api.module.Attendance;



public class AttendanceMapper  implements RowMapper<Attendance> {

	public Attendance mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Attendance attendence=new Attendance();
		attendence.setCommitId(resultSet.getString(1));
		attendence.setEventId(resultSet.getInt(2));
		attendence.setComments(resultSet.getString(3));
		return attendence;
	}

}
