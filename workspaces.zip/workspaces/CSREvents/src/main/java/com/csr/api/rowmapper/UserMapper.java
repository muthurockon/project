package com.csr.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.api.module.User;


public class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		User user=new User();
		user.setCommitId(resultSet.getString(1));
		user.setInautixEmail(resultSet.getString(2));
		user.setLocationAssigned(resultSet.getString(3));
		user.setDeignation(resultSet.getString(4));
		user.setDateOfJoining(resultSet.getString(5));
		user.setWeeksPending(resultSet.getInt(6));
		return user;
	}

}
