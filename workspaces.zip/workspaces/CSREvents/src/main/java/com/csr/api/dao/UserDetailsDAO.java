package com.csr.api.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.csr.api.module.UserDetail;
import com.csr.api.rowmapper.UserDetailsMapper;


@Component
public class UserDetailsDAO extends JdbcDaoSupport {
	DataSource dataSource;
	@Autowired
	public UserDetailsDAO(DataSource dataSource) {
	
		
		setDataSource(dataSource);
	
	}
	public List<UserDetail> select()
	{
		String sql="select * from T_CSR_USER_DETAIL";
	List<UserDetail> userDetails=getJdbcTemplate().query(sql,new Object[]{}, new UserDetailsMapper());
	return userDetails;
	}

	public UserDetail selectSingle(String id)
	{
		UserDetail userDetails=null;
		String sql="select * from T_CSR_USER_DETAIL where commitId=?";
		try{
		 userDetails=getJdbcTemplate().queryForObject(sql, new Object[]{id}, new UserDetailsMapper());
		}
		catch(Exception e)
		{
			userDetails=null;
		}
		
		return userDetails;
	}
	public int insert(UserDetail value)
	{
		int result=0;
		String sql="insert into T_CSR_USER_DETAIL values(?,?,?,?,?)";
		try{
			result=getJdbcTemplate().update(sql,new Object[]{value.getCommitId(),value.getUserName(),value.getPersonalEmail(),value.getPhoneNumber(),value.getLocation()});
		}catch(Exception e)
		{
			result=0;
		}
		return result;
	}
	public UserDetail put(String id,UserDetail userDetails)
	{	
		int result=0;	
		UserDetail new_userDetails=selectSingle(id);
		String sql="update T_CSR_USER_DETAIL set personalEmail=?,phoneNumber=?,location=? where commitId=?";	
		if(new_userDetails==null)
		{
			result=0;
		}
		else
		{
			if(userDetails.getPersonalEmail()==null)
				userDetails.setPersonalEmail(new_userDetails.getPersonalEmail());
			if(userDetails.getPhoneNumber()==null)
				userDetails.setPhoneNumber(new_userDetails.getPhoneNumber());
			if(userDetails.getLocation()==null)
				userDetails.setLocation(new_userDetails.getLocation());
			result=getJdbcTemplate().update(sql,new Object[]{userDetails.getPersonalEmail(),userDetails.getPhoneNumber(),userDetails.getLocation(),id});
		}	
		return( result == 1 ?  userDetails: null);		
	}
	public UserDetail delet(String id)
	{
		UserDetail userDetails=new UserDetail();
		int result=0;
		String sql1="delete from T_CSR_USER_DETAIL where commitId=?";
		try
		{
			result = getJdbcTemplate().update(sql1, new Object[]{id});
		}
		catch(Exception e)
		{
			userDetails=null;
		}
		
		if(result==0)
		{
			userDetails=null;
			return userDetails;
		}
		else
			
		return userDetails;
	}
}
