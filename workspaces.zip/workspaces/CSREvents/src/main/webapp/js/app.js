var app=angular.module("myApp",['ngRoute']);
 app.config(function ($routeProvider,$locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when('/usersRegistration',{
        templateUrl :"usersRegistration.htm"
    })
    .when('/adminPage',{
        templateUrl :'adminPage.htm'
    })
    .when('/user',{
        templateUrl:'user.htm'

    }); 
});
            app.controller('myCtrl',function($scope,$http){
                $scope.view=false;
                $scope.selectVal=1;
                $scope.users={};
                $scope.userDetails={};
                var attendence=[];
                console.log("Inside controller");
                $scope.myClick=function(){
                    $scope.view=!$scope.view;
                     $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvents/users'
                   
                 }).then(function(response){
                     console.log("Success message")
                     $scope.users=response.data.data.output;
                 },function(response) {
                     window.alert('No users found');
                 });
                     
                }
                $scope.submitAttendence=function(){
                	
                	attendence=[];
                var k=0;
                for(var i=0;i<$scope.users.length;i++)
                	{
                	
                	if (document.getElementById($scope.users[i].commitId+'p').checked) {
                		//$scope.attendence[i]=$scope.users[i].commitId;
                		attendence.push($scope.users[i].commitId);
                  	  
                  	}
                	
                	}
                var jdata = JSON.stringify(attendence);
                window.alert(jdata);
                
                }
                
               
                
            });
            app.controller('myCtrlSelectSingle',function($scope,$http,$log){
                $scope.view1=false;
                $scope.view2=false;
                $scope.access=true;
                 $scope.options=false;
                $scope.users={};
                  $scope.userDetails={};
                console.log("Inside Select single controller");
                $scope.selectOption=function(){
                    $scope.options=!$scope.options;
                    $scope.view2=!$scope.view2;
                }
                $scope.selecrUser=function(){
                    $scope.view1=!$scope.view1;
                    $scope.view2=!$scope.view2;
                     $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvents/users/'+$scope.commitId
                   
                 }).then(function(response){
                     console.log("Success message")
                     $scope.users=response.data.data.output;
                   
                 },function(response) {
                     window.alert('No users found');
                         $scope.view1=false;
                 });
                 $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvents/user-details/'+$scope.commitId
                   
                 }).then(function(response){
                     console.log("Success message")
                     $scope.userDetails=response.data.data.output;
                     console.log($scope.userDetails);
                 },function(response) {
                     window.alert('No users found');
                         $scope.view1=false;
                 });
                        $scope.editing=function()
                        {
                            $scope.access=false;
                            $scope.viewSave=true;

                        }
                        $scope.updating=function()
                        {
                         $scope.access=true;
                         console.log($scope.userDetails[0].personalEmail);
                         var details={
                              phoneNumber   : $scope.userDetails[0].phoneNumber,
                              personalEmail : $scope.userDetails[0].personalEmail,
                              location      : $scope.userDetails[0].location,
                 };
                                var data={
                
                
                deignation: $scope.users[0].deignation,
            
                    
                  };
                            var jdata = JSON.stringify(data);
                        var jdetails=JSON.stringify(details);
                        $http.put('http://localhost:8080/CSREvents/users/'+$scope.commitId, jdata)
                        .then(function(response){
                     
                    $scope.message="updated Successfully";
                 
                 })
                         $http.put('http://localhost:8080/CSREvents/user-details/'+$scope.commitId, jdetails)
                         .then(function(response){
                     
                    $scope.message="Updated Successfully";
                    console.log($scope.message);
                  
                  // $location.path('/user');
                 })
                          $scope.viewSave=false;
                           $scope.selecrUser();
                        }
                        $scope.cancelUpdating=function(){

                         $scope.access=true;
                         $scope.viewSave=false;
                         $scope.selecrUser();
                        }
                
                
                }
                 
                $log.log($scope.users.commitId);
            });


             app.controller('myCtrlDelete',function($scope,$http){
                $scope.view2=false;
                console.log("Inside Delete single controller");
                $scope.deleteUser=function(){
                    $scope.view2=!$scope.view2;
                     $http({ 
                    method: 'DELETE',
                    url:'http://localhost:8080/CSREvents/users/'+$scope.commitIdDel
                   
                 }).then(function(response){
                     console.log("Success message")
                    $scope.message="Deleted Successfully";
                 },function(response) {
                     window.alert('No users found');
                         $scope.view2=false;
                 });
                }
                 $scope.users={};
                
            });
             
             app.controller('attCtrl', function($scope,$http){
                 $scope.viewAttrendence=false;
                 $scope.selectVal=1;
                 $scope.users={};
                 $scope.userDetails={};
                 var attendence=[];
                 console.log("Inside controller");
                 $scope.myClick=function(){
                     $scope.viewAttrendence=!$scope.viewAttrendence;
                      $http({ 
                     method: 'GET',
                     url:'http://localhost:8080/CSREvents/users'
                    
                  }).then(function(response){
                      console.log("Success message")
                      $scope.users=response.data.data.output;
                  },function(response) {
                      window.alert('No users found');
                  });
                      
                 }
                 $scope.submitAttendence=function(){
                 	
                 	attendence=[];
                 var k=0;
                 for(var i=0;i<$scope.users.length;i++)
                 	{
                 	
                 	if (document.getElementById($scope.users[i].commitId+'p').checked) {
                 		//$scope.attendence[i]=$scope.users[i].commitId;
                 		attendence.push($scope.users[i].commitId);
                   	  
                   	}
                 	
                 	}
                 var jdata = JSON.stringify(attendence);
                 window.alert(jdata);
                 $http.post('http://localhost:8080/CSREvents/attendence-records', jdata).then(function(response){
                      
                     $scope.message="Inserted Successfully";
                   //  $window.location.href = '/user';
                   // $location.path('/user');
                  },function(response) {
                      window.alert('No users found');
                    
                  })
                 }
                 
                
                 
             });
             
             
             
             
             //registration
         	var place;
        	app.controller("registerUserController", function ($scope,$window,$http,$filter) {
        		
        		$scope.designation= ["TRAINEE", "OTHER"];
                $scope.myClick=function(id,emailId,joiningDate,name,perEmail,phNumber,places){

                


                  var a = $filter('date')(joiningDate, "MM-dd-yyyy");

                    var data={
                        commitId: id,
                  inautixEmail: emailId,
                  
                  deignation: $scope.selectedDesignation,
                  dateOfJoining: a,
                      
                    };

              var details={
                       commitId : id,
                       userName : name,
                       personalEmail : perEmail,
                       phoneNumber : phNumber,
                       location : $scope.user.from,

              };
                    var jdata = JSON.stringify(data);
                    var jdetails=JSON.stringify(details);

                              window.alert(jdata);    
                               window.alert(jdetails); 
                         

                    
                     $http.post('http://localhost:8080/CSREvents/users', jdata).then(function(response){
                       
                      $scope.message="Inserted Successfully";
                      $http.post('http://localhost:8080/CSREvents/user-details', jdetails).then(function(response){
                          
                          $scope.message="Inserted Successfully";
                        
                        // $location.path('/user');
                       },function(response) {
                           window.alert('No users found');
                         
                       })  
                    //  $window.location.href = '/user';
                    // $location.path('/user');
                   },function(response) {
                       window.alert('No users found');
                     
                   })
                      
                }
           
            $scope.user = {'from': '', 'fromLat': '', 'fromLng' : ''};
            var options = {
                componentRestrictions: {country: "in"}
            };
            var inputFrom =document.getElementById('from');
           
             //document.getElementById('from');
            var autocompleteFrom = new google.maps.places.Autocomplete(inputFrom, options);
            google.maps.event.addListener(autocompleteFrom, 'place_changed', function() {
            	//$window.alert($scope.place_start);
                place = autocompleteFrom.getPlace();
                $scope.user.fromLat = place.geometry.location.lat();
                $scope.user.fromLng = place.geometry.location.lng();
                $scope.user.from = place.address_components[0].long_name;
                $scope.$apply();
            });
            //end of google
            //remaining controller code here
            
            
            
            
            
         //end of controller   
        });
             
        	
        	
        	
        	app.controller('dateCtrl',function($scope,$http,$location,$window,$filter){
                $scope.viewAssignDate=false;
              $scope.optionDate=false;
              $scope.locationDisplay=false;
                $scope.users={};
                 
                console.log("Inside Select single controller");
                $scope.showDate=function(){
                    $scope.viewAssignDate=!$scope.viewAssignDate;
                }
                $scope.finalized=function(){
                    $scope.optionDate=!$scope.optionDate;
                        var dateofJoining = $filter('date')($scope.dateOfJoining, "MM-dd-yyyy");
                     $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvents/records/'+dateofJoining
                   
                 }).then(function(response){
                     console.log("Success message")
                     $scope.users=response.data.data.output;
                   window.alert("sucess");
                 },function(response) {
                     window.alert('No users found');
                         $scope.view1=false;
                 });
                
                        
                         
                        }
                $scope.showAssasination=function(){
                         $scope.optionDate=!$scope.optionDate;
                           $scope.locationDisplay=!$scope.locationDisplay;
                }
        	
        	 });
        	
        	
        	
             
           