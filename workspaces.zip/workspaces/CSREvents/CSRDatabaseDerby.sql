create table T_CSR_USER(commitId varchar(20) primary key,inautixEmail varchar(30),locationAssigned varchar(30),designation varchar(20),dateOfJoining date,weeksPending int);
create table T_CSR_USER_DETAIL(commitId varchar(20),userName varchar(30),personalEmail varchar(20),phoneNumber varchar(11),location varchar(30));
create table T_CSR_ATTENDENCE(commitId varchar(20),dateAttended date,comments varchar(20));
create table  T_CSR_Places(placeId INT PRIMARY KEY ,name varchar(30),address varchar(500),loaction varchar(30),contactNumber varchar(11));
create table T_CSR_Events(placeId INT,description varchar(500),eventDate Date,eventIncharge varchar(200));
insert into T_CSR_USER values('xbbnh7v','muvaidyanathan@inautix.co.in',null,'TRAINEE',DATE('2017-06-14'),12);
                                               												
