package com.training;

public class ABT implements CarDealer{
	

	
	private InsuranceAgent insuranceAgent;
	private simple s;
	public void setS(simple s) {
		this.s = s;
	}

	public InsuranceAgent getInsuranceAgent() {
		return insuranceAgent;
	}

	public void setInsuranceAgent(InsuranceAgent insuranceAgent) {
		this.insuranceAgent = insuranceAgent;
	}

	
    public void deliverCar(){
    	System.out.println("from ABT");
    	insuranceAgent.insure();
		
		s.disp();
		
		
	}
	
	

}
