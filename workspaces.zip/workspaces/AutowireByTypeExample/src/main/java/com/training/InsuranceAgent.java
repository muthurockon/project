package com.training;

public class InsuranceAgent {
	
	public void insure(){
		
		System.out.println("car is insured");
	}

}
