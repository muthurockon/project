package com.training;

public class simple {
public void disp()
{
	System.out.println("Hello");
}
}
