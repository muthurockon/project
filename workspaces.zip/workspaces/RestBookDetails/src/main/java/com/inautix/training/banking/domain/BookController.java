package com.inautix.training.banking.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;





import com.inautix.training.book.controller.BookDAO;
import com.inautix.training.dao.Book;

@RestController
@RequestMapping("/demo")
public class BookController {
	@Autowired
	BookDAO restDao;
@RequestMapping(value="/select",method=RequestMethod.GET)
	public List<Book> display()
	{
		List<Book> ls=new ArrayList<Book>();
		ls=restDao.getAllBooks();
		//System.out.println(ls);
		return ls;
		
	}
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public int insert(@RequestBody Book rb)
	{
	int id=restDao.createNewBook(rb);
	return id;
	}
	@RequestMapping(value="/put/{id}",method=RequestMethod.PUT)
	public int put(@PathVariable(value="id") int id,@RequestBody Book b)
	{
		
		//b.setId(id);
		int x=restDao.updateNewBook(id,b);
		return x;
	}
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	public int  delet(@PathVariable(value="id") int id)
	{
		int x=restDao.deleteNewBook(id);
		return x;
		
	}
	}
