package com.inautix.training.book.controller;

import java.util.List;

import javax.sql.DataSource;
import javax.sql.rowset.JdbcRowSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.inautix.training.dao.Book;

@Component
public class BookDAO {
private DataSource dataSource;
private JdbcTemplate ob;
@Autowired
public void setDataSource(DataSource dataSource) {
	this.dataSource = dataSource;
	this.ob=new JdbcTemplate(dataSource);
}
public int createNewBook(Book b)
{
	String sql="insert into book values ("+b.getId()+",'"+b.getBook_name()+"','"+b.getAuthor()+"')";
	System.out.println("sql"+sql);
	int id=ob.update(sql);
	return id;
}
public int updateNewBook(int id1,Book b)
{
	String sql="update book set book_name='"+b.getBook_name()+"',author='"+b.getAuthor()+"' where id="+id1;
	System.out.println("sql"+sql);
	int id=ob.update(sql);
	return id;
}
public int  deleteNewBook(int id)
{
	String sql="delete from book where id="+id;
	System.out.println("sql"+sql);
	int x=ob.update(sql);
	return x;
	
}
public List getAllBooks()
{
	List book=null;
	String sql="select * from book";
	book=ob.query(sql, new Object[]{}, new BookMapper());
	return book;
	
	
}
public Book getConceredBook(int id)
{
	String sql="select * from book where id="+id;
	Book b=ob.queryForObject(sql, new Object[]{}, new BookMapper());
	return b;
}

}
