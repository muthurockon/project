select * from book order by id ;
update book set book_name='water',author='ram' where id=102;