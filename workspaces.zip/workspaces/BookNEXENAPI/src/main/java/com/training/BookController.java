package com.training;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;




@EnableSwagger2
@RestController
public class BookController {
	
	
	Map<Integer, Book> bookData= new HashMap<Integer, Book>();

	@RequestMapping(value = "/books/dummy", method = RequestMethod.GET)
	public @ResponseBody  Book getDummyBook()
{
	Book b=new Book();
	b.setBookId(9999);
	b.setBookAuthor("dummy");
	b.setBookName("dummy");;
	b.setBookPrice("0");
	b.setMessage("this is a dummy one");
	bookData.put(9999, b);
	return b;
	
	
}
	@ApiOperation(value="retrive the book record using Get method",notes="returns the booka data with book id")
	@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response" ),    @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 201, message = "Created Response") })
	@RequestMapping(value="/books/{id}", method=RequestMethod.GET)
 public ResponseEntity<Object> getBook(@PathVariable("id")   int bookId)	
 {
		Book book=new Book();
		ResponseEntity<Object> responseEntity=null;
		if(bookData.containsKey(bookId))
		{
			book=bookData.get(bookId);
			responseEntity=new ResponseEntity<Object>(book, HttpStatus.OK);
			
		}
		else
		{
			Error error=new Error();
			error.setCode("TRA2001");
			error.setDescription("Book id Not Found");
			responseEntity=new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
			
		}
		return responseEntity;
		
 }
	
@ApiOperation(value="Retrives all the books details using Get method",notes="retrun the list of all books")
@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response" ),    @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 201, message = "Created Response") })
@RequestMapping(value="/books",method=RequestMethod.GET)	
public ResponseEntity<List> getAllBooks()
{
	ResponseEntity<List> responseEntity=null;
	List<Book> books=new ArrayList<Book>();
	Set<Integer> bookIdKeys=bookData.keySet();
	for(Integer i:bookIdKeys)
	{
		books.add(bookData.get(i));
	}
	if(books.isEmpty())
	{
		Error error=new Error();
		error.setCode("TRA2001");
		error.setDescription("Book records Not Found");
		List errors=new ArrayList();
		errors.add(error);
		responseEntity=new ResponseEntity<List>(errors, HttpStatus.NOT_FOUND);
		
	}
	else
		responseEntity=new ResponseEntity<List>(books, HttpStatus.OK);
	return responseEntity;
}
@ApiOperation(value="save a book details using post method",notes="create book data")
@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response" ),    @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 201, message = "Created Response") })
	@RequestMapping(value="/books",method=RequestMethod.POST)
public ResponseEntity<Object> createBook(@RequestBody Book book)
{
		ResponseEntity<Object> responseEntity=null;
		if(bookData.containsKey(book.getBookId()))
		{
			Error error=new Error();
			error.setCode("TRA2002");
			error.setDescription("Book already Exist");
			responseEntity=new ResponseEntity<Object>(error,HttpStatus.CONFLICT);
			
		}
		else
		{
			bookData.put(book.getBookId(), book);
			responseEntity=new ResponseEntity<Object>(book,HttpStatus.CREATED);
		}
		return responseEntity;
}
@ApiOperation(value = "Delete a book record using GET method",notes = "Delete the book data with student id")
@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response" ),    @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 201, message = "Created Response") })
@RequestMapping(value="/books/{id}",method=RequestMethod.DELETE)
public ResponseEntity<Object> deleteBook(@PathVariable("id") int bookId)
{
	ResponseEntity<Object> responseEntity=null;
	if(bookData.containsKey(bookId))
	{
		Book book=bookData.get(bookId);
		bookData.remove(bookId);
		book.setMessage("deleted an entry with id"+book.getBookId());
		responseEntity=new ResponseEntity<Object>(book, HttpStatus.OK);
	}
	else{
		Error error=new Error();
		error.setCode("TRA2003");
		error.setDescription("Book id not found");
		responseEntity=new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}
	return responseEntity;
}
	

@ApiOperation(value = "Update a Book record using PUT method",notes = "Update the Book data with book id")
@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response" ),    @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 201, message = "Created Response") })
@RequestMapping(value="/books/{id}",method=RequestMethod.PUT)
public ResponseEntity<Object> updatebook(@PathVariable("id") int bookId,@RequestBody Book new_book)
{
	ResponseEntity<Object> responseEntity=null;
	if(bookData.containsKey(bookId))
	{
		Book book=new Book();
		book.setBookAuthor(new_book.getBookAuthor());
		book.setBookId(new_book.getBookId());
		book.setBookName(new_book.getBookName());
		book.setBookPrice(new_book.getBookPrice());
		bookData.put(book.getBookId(), book);
		book.setMessage("Updated an entry with id " +book.getBookId());
		responseEntity=new ResponseEntity<Object>(book,HttpStatus.OK);
	}
	else
	{
		Error error=new Error();
		error.setCode("TRA2003");
		error.setDescription("Book id Not Found");
		responseEntity=new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}
	return responseEntity;
}





	
}
	
	
	
	
	
	
	
	
