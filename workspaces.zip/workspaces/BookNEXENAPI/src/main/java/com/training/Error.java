package com.training;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlRootElement;

@Generated("org.jsonschema2pojo")
@XmlRootElement(name = "Errors")
public class Error {

	private String code;
	private String description;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
