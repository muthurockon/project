package com.training.api.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import javax.activity.InvalidActivityException;
import javax.naming.NameNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.training.api.dao.BookDAO;
import com.training.api.model.Book;
import com.training.api.model.Data;
import com.training.api.model.Error;
import com.training.api.model.MetaData;
import com.training.api.model.Response;

import springfox.documentation.swagger2.annotations.EnableSwagger2;



@EnableSwagger2
@RestController

public class BookController {
@Autowired
	BookDAO bookDao;
@Autowired
MetaData metaData;
@Autowired
Data data;
@Autowired
Response response;
@Autowired
Error error;
@ApiOperation(value="retrive the book record using Get method",notes="returns the booka data with book id")
@ApiResponses(value={  @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
@RequestMapping(value="/books",method=RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})


public ResponseEntity<Response> display()
{
	List<Book> book;
	try {
		book=bookDao.select();
          if(book.isEmpty())
          {
        	  error.setCode("TRA2007");
      		error.setDescription("No data is present in the table");
      		saveMetaData(false,"Data not found in table","2001");
      		
      		saveResponse(null,metaData,error);
      		return new ResponseEntity<Response>(response, HttpStatus.OK) ;
        	  
          }
          else
          {
		saveMetaData(true,"found Successfully","2008");
		saveData(null, book);
		saveResponse(data,metaData, null);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
          }
	} catch (Exception e) {
		// TODO Auto-generated catch block
		error.setCode("TRA2001");
		error.setDescription(e.getMessage());;
		saveMetaData(false,"Invalid Entry","2002");
		
		saveResponse(null,metaData,error);
		return new ResponseEntity<Response>(response, HttpStatus.OK) ;
		//return response;
	}
	
}








@ApiOperation(value="retrive the book record using Get method",notes="returns the booka data with book id")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/books/{bookId}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displaySingle(@ApiParam(value = "object that need to be displayed", required = true) @PathVariable("bookId") String new_bookId) 
{
	
	List<Book> testList = new ArrayList<Book>();
	
		
		try {
		
				
			int bookId=Integer.parseInt(new_bookId);
		
		
			if(bookId<=0){
				throw new ArithmeticException();
					}
			
			Book book = bookDao.selectSingle(bookId);
			 if(book==null)
				{
					saveMetaData(false,"Id not found in table","2008");
					error.setCode("TRA2001");
					error.setDescription("Invalid ID");
//					saveData(errorDetails, null);
					saveResponse(null,metaData, error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				}
				else
				{
			testList.add(book);
			
			saveMetaData(true,"successfully found","2005");
			saveData(null, testList);
			saveResponse(data,metaData, null);
			return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			error.setCode("TRA2002");
			
			if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if( e instanceof DataAccessException)
				error.setDescription("Database error");
			else if(e instanceof ArithmeticException)
				error.setDescription("Invalid ID  should not be neagative or zero");
			else if(e instanceof InvalidActivityException)
				error.setDescription("Invalid ID  should not be .");
			else
				error.setDescription("Input url must not be of string type");;
			saveMetaData(false,"Invalid enrty/type","2009");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, error);
			//return response;
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
			
		}
			
	
}
















@ApiOperation(value="retrive the book record using Post method",notes="creates book with new id")
@ApiResponses(value={ @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
@ResponseStatus(HttpStatus.ACCEPTED)
@ExceptionHandler(MissingServletRequestParameterException.class)


@RequestMapping(value="/books",method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> insert(@RequestBody Book book)
{
	List<Book> testList = new ArrayList<Book>();
	
	
	try{

		if(book.getBookId()!=0&&book.getBookAuthor()!=null&&book.getBookAuthor().length()<8&&book.getBookName()!=null&&book.getBookPrice()>=10&&book.getBookAuthor()!=""&&book.getBookName()!=""&&book.getBookId()>0){			
		book=bookDao.insert(book);	
		
		if(book!=null){
		testList.add(book);			
		saveMetaData(true,"Created","201");
		saveData(null, testList);
		saveResponse(data,metaData, null);
		return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}
		else
		{

			error.setCode("TRA2003");
			error.setDescription("Books not created");
			saveMetaData(false,"Invalid Type","2008");
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
		}
		else
		{
			error.setCode("TRA2004");
			error.setDescription("Book not created");
			saveMetaData(false,"Invalid Type ","2010");
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
		
	}
	catch(Exception e){
		e.printStackTrace();			
		error.setCode("TRA2002");
		 if (e instanceof DataAccessException)
		   {
		error.setDescription("Book id already Exist");
		   }
		 else{
			 error.setDescription(e.getMessage());
		 }
		saveMetaData(false,"Book already Existt","2009");
		//saveData(errorDetails, null);
		saveResponse(null,metaData, error);
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
	}	
	
}


@ApiOperation(value="retrive the book record using Put method",notes="update the booka data with book id")
@ApiResponses(value={
		@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),   
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),   
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), 
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/books/{bookId}",method=RequestMethod.PUT,produces={MediaType.APPLICATION_JSON_VALUE},consumes=MediaType.APPLICATION_JSON_VALUE
)


public ResponseEntity<Response> put(@ApiParam(value = "object that need to be updated", required = true)@PathVariable(value="bookId") String new_bookId,@RequestBody Book new_book)
{
	List<Book> testList = new ArrayList<Book>();
	try{
		if(new_bookId==null)
			throw new NullPointerException();
		int bookId=Integer.parseInt(new_bookId);
		if(bookId<=0)
			throw new ArithmeticException();
		if(new_book.getBookName()==null&&new_book.getBookAuthor()==null&new_book.getBookPrice()<=0)
	    	 throw new NameNotFoundException();
		new_book=bookDao.put(bookId, new_book);	
	     
		if(new_book==null)
		{
			error.setCode("TRA2005");
			error.setDescription("Invalid ID");;
			saveMetaData(false,"Id not found","2404");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else{
		
			//Book book=bookDao.selectSingle(bookId);
		testList.add(new_book);		
		saveMetaData(true,"Successfully updated","2008");
		saveData(null, testList);
		saveResponse(data,metaData,null);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	}
	catch(Exception e){
		e.printStackTrace();			
		error.setCode("TRA2005");
		if(e instanceof ArithmeticException){
			error.setDescription("Id should be not negative and zero");
			saveMetaData(false,"Not Acceptable form","2008");
		}
		else if(e instanceof NameNotFoundException)
		{
			error.setDescription("no data writen to update");
			saveMetaData(false,"No Entry Available for update","2009");

		}
		else if(e instanceof NullPointerException)
		{
			error.setDescription("Invalid url type");
			saveMetaData(false,"Not valid url","2009");
		}
			else
			{
		error.setDescription("Miss match type book id should not be String");
		saveMetaData(false,"Not Acceptable in the form as String Entry","2008");
			}
		//saveData(errorDetails, null);
		saveResponse(null,metaData, error);
		//return response;
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
	}	
	
}

@ApiOperation(value="retrive the book record using delete method",notes="delete the booka data with book id")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),  
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class),
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/books/{bookId}",method=RequestMethod.DELETE,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> delete(@ApiParam(value = "object that need to be deleted", required = true)@PathVariable(value="bookId") String new_bookId)
{
	List<Book> testList = new ArrayList<Book>();
	try{
		int bookId=Integer.parseInt(new_bookId);
		if(bookId<=0)
			throw new ArithmeticException();
		
		Book book=bookDao.delet(bookId);	
		if(book==null)
		{
			error.setCode("TRA2006");
			error.setDescription("Record not found");;
			saveMetaData(false,"Id is not found","2404");
			saveData(error, null);
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else
			
		{
			testList.add(book);			
			saveMetaData(true,"successfully deleted","2009");
			saveData(null, testList);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
		
		
	}
	catch(Exception e){
		
		e.printStackTrace();			
		error.setCode("TRA2005");
		if(e instanceof ArithmeticException)
			error.setDescription("bookId should not be non negative or zero");
		else
		error.setDescription("Miss match type book id should not be String");;
		saveMetaData(false,"Not Acceptable","406");
		//saveData(errorDetails, null);
		saveResponse(null,metaData, error);
		//return response;
		return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
	}	

}
private void saveResponse(Data data, MetaData metaData, Error errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}

private void saveData(Error erroDet, List<Book> testObj) {
	response.setError(erroDet);
	data.setOutput(testObj);

}

private void saveMetaData(boolean success, String description, String responseId) {
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}
}