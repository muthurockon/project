package com.training.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.api.model.Book;



public class BookMapper implements RowMapper<Book> {


	public Book mapRow(ResultSet resultSet, int rowNUM) throws SQLException {
		// TODO Auto-generated method stub\
		Book book=new Book();
		book.setBookId(resultSet.getInt(1));
		book.setBookAuthor(resultSet.getString(2));
		book.setBookName(resultSet.getString(3));
		book.setBookPrice(resultSet.getInt(4));
		return book;
	}

}
