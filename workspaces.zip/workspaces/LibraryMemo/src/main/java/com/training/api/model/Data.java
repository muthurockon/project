package com.training.api.model;

import java.util.List;





import io.swagger.annotations.ApiModelProperty;

public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "output usd for the type to conatain list of books")
	private List<Book> output;
	@ApiModelProperty(position = 2, required = false, value = "contains value of book beans ")

	private Book book;
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public List<Book>  getOutput() {
		return output;
	}
	public void setOutput(List<Book> outputList) {
		this.output = outputList;
	}
}
	