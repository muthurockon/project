package com.training.api.model;

import io.swagger.annotations.ApiModelProperty;

public class Book {
    
 @ApiModelProperty(position = 1, required = true, value = "Holds the bookId")
int bookId;
 @ApiModelProperty(position = 2, required = true, value = "contains the author name")
String bookAuthor;
 @ApiModelProperty(position = 3, required = true, value = "contains book name ")
 String bookName;
 @ApiModelProperty(position = 4, required = true, value = "contains book price")
 int bookPrice;
 @ApiModelProperty(position = 5, required = false, value = "contains the message needed to be pdated in it")
 String message;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
