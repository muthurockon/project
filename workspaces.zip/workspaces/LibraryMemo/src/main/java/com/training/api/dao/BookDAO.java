package com.training.api.dao;


import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.training.api.model.Book;
import com.training.api.rowmapper.BookMapper;

@Component
public class BookDAO extends JdbcDaoSupport{
DataSource dataSource;
@Autowired
public BookDAO(DataSource dataSource)
{
	this.dataSource=dataSource;
	setDataSource(dataSource);
}

public List<Book> select()
{
List<Book> ls=getJdbcTemplate().query("select * from books",new Object[]{}, new BookMapper());
return ls;
}

public Book selectSingle(int id)
{
	Book book=null;
	try{
	 book=getJdbcTemplate().queryForObject("select * from books where bookId="+id, new Object[]{}, new BookMapper());
	}
	catch(Exception e)
	{
		book=null;
	}
	
	return book;
}
public Book insert(Book value)
{
	int a=0;
	value.setMessage("inserted");

	a=getJdbcTemplate().update("insert into books values(?,?,?,?)",new Object[]{value.getBookId(),value.getBookAuthor(),value.getBookName(),value.getBookPrice()});


	return( a == 1 ?  value: null);
}
public Book put(int id,Book book)
{	int a=0;
	Book new_book=selectSingle(id);
	if(new_book==null)
	{
		a=0;
	}
	else
	{
	book.setBookId(id);
			if(book.getBookAuthor()==null)
				book.setBookAuthor(new_book.getBookAuthor());
			if(book.getBookName()==null)
				book.setBookName(new_book.getBookName());
			if(book.getBookPrice()<=0)
				book.setBookPrice(new_book.getBookPrice());
		
	a=getJdbcTemplate().update("update books set bookName=?,bookAuthor=?,bookPrice=? where bookId=?",new Object[]{book.getBookName(),book.getBookAuthor(),book.getBookPrice(),id});

	}
	
	
return( a == 1 ?  book: null);
	
	
}
public Book delet(int id)
{

	Book book=new Book();
	int a=0;
	try
	{
		 book=getJdbcTemplate().queryForObject("select * from books where bookId="+id, new Object[]{}, new BookMapper());
		book.setMessage("deleted successfully");
		a = getJdbcTemplate().update("delete from books where bookId="+id, new Object[]{});
	}
	catch(Exception e)
	{
		book=null;
	}
	
	if(a==0)
	{
		book=null;
		return book;
	}
	else
		
	return book;
}
}