package com.training;

import java.util.Iterator;
import java.util.List;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inautix.training.banking.controller.CustomerController;
import com.inautix.training.banking.domain.Customer;

public class GetAllCustomersDemo {
	
	
	public static void main(String arg[]){
		
		// loading the definitions from the given XML file
				ApplicationContext context = new ClassPathXmlApplicationContext(
						"applicationContext.xml");
		 
				CustomerController controller = (CustomerController) context.getBean("controller");
				
				//Customer customer = new Customer();
				
				
				//controller.createCustomer(customer);
				
				List customerList = controller.getAllCustomers();
				
				Iterator customerListIterator = customerList.iterator();
				
				while(customerListIterator.hasNext()){
					
					Customer customer = (Customer)customerListIterator.next();
							
					System.out.println("Customer Id "+customer.getCustomerId());
					
					System.out.println("Customer Name "+customer.getCustomerName());
					System.out.println("Customer Location "+customer.getLocation());
					
					
				}
				
				
			}
		
	}


