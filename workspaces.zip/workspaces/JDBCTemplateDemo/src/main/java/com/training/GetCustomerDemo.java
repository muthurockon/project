package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inautix.training.banking.controller.CustomerController;
import com.inautix.training.banking.domain.Customer;

public class GetCustomerDemo {
	
	public static void main(String arg[]){
	// loading the definitions from the given XML file
	ApplicationContext context = new ClassPathXmlApplicationContext(
			"applicationContext.xml");

	CustomerController controller = (CustomerController) context.getBean("controller");
	
	Customer customer = controller.getCustomerDetails(15938);
	
	System.out.println("Customer Id "+customer.getCustomerId());
	
	System.out.println("Customer Name "+customer.getCustomerName());
	System.out.println("Customer Location "+customer.getLocation());


}

}