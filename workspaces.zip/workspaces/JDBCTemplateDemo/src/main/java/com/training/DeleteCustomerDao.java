package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inautix.training.banking.controller.CustomerController;
import com.inautix.training.banking.domain.Customer;

public class DeleteCustomerDao {
	
	public static void main(String arg[]){
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");

		CustomerController controller = (CustomerController) context.getBean("controller");
		
		controller.deleteCustomer(1);
		


}
}