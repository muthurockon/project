package com.inautix.training.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;


import com.inautix.training.banking.domain.Customer;
import com.inautix.training.banking.dao.CustomerMapper;

public class CustomerDAO {
	
	private DataSource dataSource;
	   private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	
	public void createCustomer(Customer customer){
		
      String sql ="insert into Customer_xeccq49 values ("+customer.getCustomerId()+",'"+customer.getCustomerName()+"','"+customer.getLocation()+"')";
      System.out.println("sql "+sql);			

      jdbcTemplateObject.update(sql);
			
			
   }
	
	
	public void updateCustomer(Customer customer){
		
		String sql="update Customer_xeccq49 set location='" +customer.getLocation()+"' where Customer_id=" + customer.getCustomerId();
		 System.out.println("sql "+sql);	
		 
		 jdbcTemplateObject.update(sql);
	}
	
			
public void deleteCustomer(int customerId){
		
		String sql="delete Customer_xeccq49 where Customer_id="+customerId;
		 System.out.println("sql "+sql);	
		 
		 jdbcTemplateObject.update(sql);
	}

		
	
	public List getAllCustomer(){
		
		List customerList = null;
		String sql="select * from Customer_xeccq49";
		customerList = jdbcTemplateObject.query(sql, new Object[]{}, new CustomerMapper());
	      
	    return 	customerList;
	    
	  }
		
			
	

 public Customer getCustomerDetails(int customerId) {
	 
String sql = "select * from Customer_xeccq49 where Customer_id= ?";

Customer customer=jdbcTemplateObject.queryForObject(sql, new Object[]{customerId}, new CustomerMapper());

return customer;
}
}
