package com.inautix.training.banking.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.inautix.training.banking.dao.CustomerDAO;

import com.inautix.training.banking.domain.Customer;

@Component("customerController")
public class CustomerController {
	
	@Autowired
	private CustomerDAO customerDao;
	
	
	public void createCustomer(Customer customer){
		System.out.println("inside CustomerController createCustomer");
		
		customerDao.createCustomer(customer);
		
		
	}
	
	public Customer getCustomerDetails(int customerId){
		
	    Customer customer = null;
	    customer= customerDao.getCustomerDetails(customerId);
		return customer;
	}
	
	public void updateCustomer(Customer customer){
		
		customerDao.updateCustomer(customer);
		
	}
	
	public void deleteCustomer(int customerId){
		
		customerDao.deleteCustomer(customerId);
		
	}
	
	
	public List getAllCustomers(){
		List CustomerList = null;
		
		
		CustomerList = customerDao.getAllCustomer();
		return CustomerList;
	}
	
	
		
	

}
