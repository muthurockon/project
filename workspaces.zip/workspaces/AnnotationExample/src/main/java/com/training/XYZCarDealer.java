package com.training;

import org.springframework.beans.factory.annotation.Autowired;

public class XYZCarDealer implements CarDealer{
	
	@Autowired
	private CarCompany myCarcompany;
	
	
	
	public XYZCarDealer(){
		
		
	}
	
	
	
	public void deliverCar(){
		
		myCarcompany.deliverCar();
		
	}



	

}
