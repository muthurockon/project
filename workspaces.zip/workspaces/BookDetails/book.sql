create table book(id int,book_name varchar(20),author varchar(20));
create table sales(id int,book_no int,rate int);
create table purchase(id int,name varchar(20),address varchar(20));
insert into book  values(100,'fire','arnold');
insert into book  values(101,'water','jackson');
insert into book  values(102,'air','warnick');
insert into book  values(103,'great','andrio');
insert into book  values(104,'much','mahi');
delete from book where id=102
select * from book;