package com.inautix.training.book.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.inautix.training.dao.Book;

public class BookMapper implements RowMapper<Book> {

	public Book mapRow(ResultSet rs, int rowNUM) throws SQLException {
		// TODO Auto-generated method stub\
		Book b=new Book();
		b.setId(rs.getInt(1));
		b.setBook_name(rs.getString(2));
		b.setAuthor(rs.getString(3));
		return b;
	}

}
