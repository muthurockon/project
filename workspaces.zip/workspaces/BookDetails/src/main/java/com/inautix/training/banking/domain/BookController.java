package com.inautix.training.banking.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.inautix.training.book.controller.BookDAO;
import com.inautix.training.dao.Book;



@Controller
public class BookController {
	@Autowired
	private BookDAO bookDAO;
	
	@RequestMapping("/bookform")
	public ModelAndView showform()
	{
		return new ModelAndView("bookform", "command", new Book());
	}
	
	 @RequestMapping(value="/save",method = RequestMethod.POST)  
		public ModelAndView createCustomer(@ModelAttribute("book") Book book){
			System.out.println("inside CustomerController createCustomer");
			
			bookDAO.createNewBook(book);
			
			return new ModelAndView("redirect:/viewbookform");
			
		}
	 @RequestMapping(value="/editbook/{id}")  
		public ModelAndView getCustomerDetails(@PathVariable  int id){
			
		   Book book=null;
		   book=bookDAO.getConceredBook(id);
			
		    return new ModelAndView("bookeditform","command",book);  
		    
		}
		
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
		public ModelAndView updateCustomer(@ModelAttribute("book") Book book){
			System.out.println("inside bookController updatebook");
			bookDAO.updateNewBook(book);
			
			return new ModelAndView("redirect:/viewbookform");  
			
		}
		
		
	    @RequestMapping(value="/deletebook/{id}",method = RequestMethod.GET) 
	    public ModelAndView deleteCustomer(@PathVariable int id){
			
			bookDAO.deleteNewBook(id);
			return new ModelAndView("redirect:/viewbookform");  
			
		}
		
		@RequestMapping("/viewbookform") 
		public String getAllCustomers(ModelMap model){
			List booklist = null;
			
			
			booklist = bookDAO.getAllBooks();
			
			model.addAttribute("list",booklist);
			return "viewbookform"; 
		}
}
