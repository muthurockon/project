package com.training;

import java.util.Collection;

public class MultiCarDealer implements CarDealer{
	
	private Collection<CarCompany> carCompanies;
	
	
	
	public Collection<CarCompany> getCarCompanies() {
		return carCompanies;
	}



	public void setCarCompanies(Collection<CarCompany> carCompanies) {
		this.carCompanies = carCompanies;
	}



	public void deliverCar(){
		System.out.println("from MultiCarDealer");
		
		for(CarCompany carCompany:carCompanies){
			
			carCompany.deliverCar();
		}
		
		
	}

}
