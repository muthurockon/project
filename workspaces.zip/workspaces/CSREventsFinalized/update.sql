delete from T_CSR_Places where placeId=3
SELECT * from T_CSR_Places where loaction=lower('Besant Nagar')