create table  T_CSR_Places(placeId INT PRIMARY KEY ,name varchar(30),address varchar(500),loaction varchar(30),contactNumber varchar(11));
drop table T_CSR_Places;
create table T_CSR_Events(eventId int,eventName varchar(30),placeId INT,description varchar(500),eventDate Date,eventIncharge varchar(200));
drop table T_CSR_Events;
create table T_CSR_USER(commitId varchar(20) primary key,inautixEmail varchar(30),locationAssigned varchar(30),designation varchar(20),weeksPending int);
create table T_CSR_USER_DETAIL(commitId varchar(20),userName varchar(30),personalEmail varchar(20),phoneNumber varchar(11),location varchar(30));
create table T_CSR_ATTENDENCE(commitId varchar(20),eventId int,comments varchar(20));
drop table T_CSR_ATTENDENCE;

describe T_CSR_USER;
update T_CSR_Places set loaction='Besant nagar' where placeId=4;

update T_CSR_USER_DETAIL set location='Tambaram' where commitId='xbbnh7v';