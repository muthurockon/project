package com.csr.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.bean.Event;

public class EventRowMapper implements RowMapper {

	public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Event event=new Event();
		event.setEventId(rs.getInt("eventId"));
		event.setEventName(rs.getString("eventName"));
		event.setPlaceId(rs.getInt("placeId"));
		event.setDescription(rs.getString("description"));
		event.setEventDate(String.valueOf(rs.getDate("eventDate")));
		event.setEventLead(rs.getString("eventIncharge"));
		return event;
	}

}
