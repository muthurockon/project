package com.csr.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.bean.Location;

public class LocationMapper implements RowMapper<Location> {

	public Location mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Location location=new Location();
		location.setCommitId(resultSet.getString(1));
		location.setInautixEmail(resultSet.getString(2));
		location.setLocationAssigned(resultSet.getString(3));
		location.setDeignation(resultSet.getString(4));
		location.setDateOfJoining(resultSet.getString(5));
		location.setWeeksPending(resultSet.getInt(6));
		location.setLocation(resultSet.getString(7));
	return location;
	}

}
