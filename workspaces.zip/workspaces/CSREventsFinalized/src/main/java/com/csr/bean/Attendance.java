package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class Attendance {
	@ApiModelProperty(position = 1, required = true, value = "Holds the commitId")
String commitId;
	@ApiModelProperty(position = 2, required = true, value = "Holds the userAttended")
int eventId;
	@ApiModelProperty(position = 3, required = true, value = "Holds the comments")
String comments;
public String getCommitId() {
	return commitId;
}
public void setCommitId(String commitId) {
	this.commitId = commitId;
}

public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}

}
