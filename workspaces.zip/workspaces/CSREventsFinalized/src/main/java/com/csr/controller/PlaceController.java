package com.csr.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.csr.bean.Place;
import com.csr.dataaccess.PlaceDAO;
import com.csr.model.Data;
import com.csr.model.Error;
import com.csr.model.MetaData;
import com.csr.model.Response;

@EnableSwagger2
@RestController
public class PlaceController {
	 @Autowired
	  PlaceDAO places;
	   @Autowired
	   MetaData metaData;
	   @Autowired
	   Data data;
	   @Autowired
	   Response response;
	   @Autowired
	   Error error;
		
	  //  private userservice userservice;
		@ApiOperation(value="Retrieve place records using GET method",notes="Returns the place data")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
		@RequestMapping(value ="/places" , method = RequestMethod.GET,  produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> getAllRecords() {
			System.out.println("in");
			ResponseEntity res=null;
			List<Place> place = new ArrayList<Place>();  
			place=places.getAllRegisteredPlaces();
			//List<String> place=places.getUniqueLocations();
			if(!place.isEmpty())
			{
				saveMetaData(true,"Details found","1001");
				saveData(null,place);
				saveResponse(data,metaData, null);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
			else
			{
				//Error error=new Error();
				error.setCode("CSR_PLACE2001");
				error.setDescription("Result set not found");
				saveMetaData(false,"Error Occured","2001");
				saveResponse(null,metaData,error);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
			return res;
		}
		
		@ApiOperation(value="Register a place using using POST method",notes="Registration of place is performed. Duplicate places will not be inserted")
		@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
		@RequestMapping(value="/places",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
       public ResponseEntity<Response> registerPlace(@RequestBody Place place)
       {	
			System.out.println("POST place cont");
			 ResponseEntity res=null;
			 System.out.println(place.getName());
            int result= places.makePlaceEntry(place);
            if(result==-1)
            {
           	 error.setCode("CSR_PLACE2003");
        		error.setDescription("Unique constraint violated. ID already present");
           	 saveMetaData(false,"Error Occured. Unique constraint violated ","2003");
        		saveResponse(null,metaData,error);
           	 res=new ResponseEntity(response,HttpStatus.OK);
            }
            else if(result==-2)
			{
				error.setCode("CSR_PLACE2011");
         		error.setDescription("Mobile number should have only digits");
         		saveMetaData(false,"Bad argument.Mobile number should have only digits","2011");
         		saveResponse(null,metaData,error);
         		res=new ResponseEntity(response,HttpStatus.OK);
			}
			else if(result==-3)
			{
				error.setCode("CSR_PLACE2012");
         		error.setDescription("Name should have only alphabets");
         		saveMetaData(false,"Bad argument.Name should have only alphabets","2012");
         		saveResponse(null,metaData,error);
         		res=new ResponseEntity(response,HttpStatus.OK);
			}
            else if(result==0)
            {
           	 	error.setCode("CSR_PLACE2004");
           		error.setDescription("Enter All Details");
           		saveMetaData(false,"Error Occured. Enter all details","2004");
           		saveResponse(null,metaData,error);
           		res=new ResponseEntity(response,HttpStatus.OK);
            }
            else
            {
           	 	saveMetaData(true,"The following detail is inserted successfully","1005");
           	 	List<Place> placeList=new ArrayList();
           	 	placeList.add(place);
           	 	saveMetaData(true,"Insert success.The following detail is inserted successfully","1005");
           		saveData(null,placeList);
           		saveResponse(data,metaData, null);
           		res=new ResponseEntity(response,HttpStatus.OK);
            }
           	// response=new ResponseEntity("Insert suuccess",HttpStatus.OK);
            return res;
       }
		/*
		@ApiOperation(value="Update user record using PUT method",notes="Updates the user record . User name is updated based on the phone number")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response" ,response=Response.class),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })		
		@RequestMapping(value="/users/{phone}",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> updateUser(@ApiParam(value="Enter Id of user to update",required=true) @PathVariable("phone") String phone,@RequestBody UserBean user)
		{
			ResponseEntity res=null;
			System.out.println("in");
			int r=users.update(phone,user);
			if(r==-2)
			{
				error.setCode("CSR_PLACE2009");
        		error.setDescription("Mobile number should have only digits");
        		saveMetaData(false,"Bad argument.Mobile number should have only digits","2009");
        		saveResponse(null,metaData,error);
        		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(r==-3)
			{
				error.setCode("CSR_PLACE2010");
        		error.setDescription("Name should have only alphabets");
        		saveMetaData(false,"Bad argument.Name should have only alphabets","2010");
        		saveResponse(null,metaData,error);
        		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(r==-4)
			{
				error.setCode("CSR_PLACEE2020");
        		error.setDescription("Phone number should be 10 digit long");
        		saveMetaData(false,"Phone number should be 10 digit long","2010");
        		saveResponse(null,metaData,error);
        		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(r==-5)
			{
				error.setCode("CSR_PLACEE2021");
        		error.setDescription("Enter necessary fields");
        		saveMetaData(false,"Enter necessary fields","2010");
        		saveResponse(null,metaData,error);
        		res=new ResponseEntity(response,HttpStatus.BAD_REQUEST);
			}
			else if(r==1)
			{
				saveMetaData(true,"Update success. The following field is upadated","1005");
				List<UserBean> usr=new ArrayList();
				usr.add(users.getUserById(phone));
       	 	System.out.println(usr.size());
				saveData(null,usr);
				saveResponse(data,metaData, null);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
				
			else
			{
				//error=new Error("CSR_PLACE2005","Record ID to be updated not found");
				 error.setCode("CSR_PLACE2005");
        		error.setDescription("Record ID to be updated not found");
        		saveMetaData(false,"Error Occured.Record ID to be updated not found","2005");
        		saveResponse(null,metaData,error);
				res=new ResponseEntity(response,HttpStatus.NOT_FOUND);
			}
			return res;
		}
		*/
		@ApiOperation(value="Delete a user record using DELETE method",notes="User can de activate his account by doing this operation. The account will be deleted")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
		@RequestMapping(value="/places/{placeId}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> deleteUser(@ApiParam(value="Enter ID of the user to delete",required=true)@PathVariable(value="placeId") String placeId)
		{
			ResponseEntity resp=null;
			System.out.println("Delete");
			int pid=Integer.parseInt(placeId);
			int result=places.delete(pid);
			System.out.println("Hello Delete");
			if(result==-1)
			{
				error.setCode("CSR_PLACE2007");
        		error.setDescription("Exception occured");
        		saveMetaData(false,"Exception occured","2007");
        		saveResponse(null,metaData,error);
        		resp=new ResponseEntity(response,HttpStatus.OK);
			}
			else if(result==1)
			{
				saveMetaData(true,"Delete success. The remaining data after deletion is displayed","1006");
				List<Place> place=new ArrayList();
				place=places.getAllRegisteredPlaces();
				saveData(null,place);
				System.out.println();
				saveResponse(data,metaData, null);
				resp=new ResponseEntity(response,HttpStatus.OK);
			}	
			else
			{
				 error.setCode("CSR_PLACE2026");
	         		error.setDescription("Place ID to be deleted not found");
	         		saveMetaData(false,"Place ID to be deleted not found","2026");
	         		saveResponse(null,metaData,error);
				resp=new ResponseEntity(response,HttpStatus.OK);
			}
			return resp;
		}
		
		@ApiOperation(value="Retrieve a user record using GET method",notes="Returns the user data with particular phone number")
		@ApiResponses(value = {    @ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
		@RequestMapping(value = "/places/{placeId}" , method = RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE )
		public ResponseEntity<Response> getUserByPhone(@ApiParam(value="Enter phone number of user to fetch",required=true) @PathVariable("placeId") String placeId) {
			ResponseEntity res=null;
			System.out.println("in");
			Place place = null;  
			int pid=Integer.parseInt(placeId);
			place=places.getPlaceById(pid);
			if(place!=null)
			{
				saveMetaData(true,"Details found","1001");
				List<Place> placeList=new ArrayList();
				placeList.add(place);
				saveData(null,placeList);
				saveResponse(data,metaData, null);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
			else
			{
				
				 error.setCode("CSR_PLACE2002");
	         		error.setDescription("Record not found");
	         		saveMetaData(false,"Error Occured.Record not found","2002");
	         		saveResponse(null,metaData,error);
				res=new ResponseEntity(response,HttpStatus.OK);
			}
			return res;
		}
		private void saveResponse(Data data, MetaData metaData, Error errorDet) {
			response.setData(data);
			response.setMetaData(metaData);
			response.setError(errorDet);
		}
		private void saveData(Error erroDet, List testObj) {
			response.setError(erroDet);
				data.setOutput(testObj);
			
		}
		private void saveMetaData(boolean success, String description, String responseId){
			metaData.setSuccess(success);
			metaData.setDescription(description);
			metaData.setResponseId(responseId);
		}
}
