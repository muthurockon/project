package com.csr.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import javax.activity.InvalidActivityException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.csr.bean.Attendance;
import com.csr.dataaccess.AttendanceDAO;
import com.csr.dataaccess.UserDAO;
import com.csr.model.Data;
import com.csr.model.Error;
import com.csr.model.MetaData;
import com.csr.model.Response;


@EnableSwagger2
@RestController
public class AttendenceController {

@Autowired
AttendanceDAO attendenceDAO;
@Autowired
UserDAO users;
@Autowired
MetaData metaData;
@Autowired
Data data;
@Autowired
Response response;
@Autowired
Error error;

@ApiOperation(value="retrive the attendance record using Get method",notes="returns the attendance record with commit id")
@ApiResponses(value={  @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
@RequestMapping(value="/attendances",method=RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> display()
{
	List<Attendance> attendances;
	saveResponse(null,metaData, null);
	try {
		attendances=attendenceDAO.getAllRecords();
          if(attendances.isEmpty())
          {
        	  error.setCode("TRA2007");
        	  error.setDescription("Attendence record not found.");
        	  saveMetaData(false,"Data not found","2001");
        	  saveResponse(null,metaData,error);
        	  return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
          }
          else
          {
        	  saveMetaData(true,"Details found.","2008");
        	  saveData(null, attendances);
        	  saveResponse(data,metaData, null);
        	  return new ResponseEntity<Response>(response, HttpStatus.OK);
          }
	} catch (Exception e) {
		// TODO Auto-generated catch block
		error.setCode("TRA2001");
		error.setDescription(e.getMessage());
		saveMetaData(false,e.getMessage(),"2002");
		saveResponse(null,metaData,error);
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		//return response;
	}
	
}








@ApiOperation(value="retrive the specific Attendence record using Get method",notes="returns the Attendence record refered with commit id")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/attendances/{commitId}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displaySingle(@ApiParam(value = "commit id of the record that need to be displayed", required = true) @PathVariable("commitId") String commitID) 
{ 
	List<Attendance> attendence=null;
		
				attendence = attendenceDAO.getByCommitId(commitID);
				if(attendence.size()==0)
				{
					saveMetaData(false,"Attandence record for commit ID "+commitID+" not found","2008");
					error.setCode("TRA2001");
					error.setDescription("Attandence record for commit ID "+commitID+" not found");
					saveResponse(null,metaData, error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				}
				else
				{
					//attendances.add(attendence);
					saveMetaData(true,"successfully found","2005");
					saveData(null, attendence);
					saveResponse(data,metaData, null);
					return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
				}
}
















@ApiOperation(value="create the Attendence record using Post method",notes="creates Attendence record with refering commitId")
@ApiResponses(value={ @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
@ResponseStatus(HttpStatus.ACCEPTED)



@RequestMapping(value="/attendances",method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> insert(@RequestBody Attendance attendence)
{
	List<Attendance> attendances = new ArrayList<Attendance>();
	int result=0;
		if(attendence.getCommitId()!=null){			
		result=attendenceDAO.insert(attendence);	
		
		if(result!=0){
			attendances.add(attendence);			
			saveMetaData(true,"Created","200");
			saveData(null, attendances);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.CREATED);
		}
		else
		{
			error.setCode("TRA2003");
			error.setDescription("Attendence record not created");
			saveMetaData(false,"Invalid Type","2008");
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
		}
		else
		{
			error.setCode("TRA2004");
			error.setDescription("Attendence record not created");
			saveMetaData(false,"Invalid Type ","2010");
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
}






@ApiOperation(value="delete a specific  the Attendence record using delete method",notes="delete the Attendence record with  commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),  
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class),
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/attendances/{commitId}",method=RequestMethod.DELETE,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> delete(@ApiParam(value = "object that need to be deleted", required = true)@PathVariable(value="commitId") String commitId)
{
	List<Attendance> attendence = new ArrayList<Attendance>();
	int result=0;
		result=attendenceDAO.delete(commitId);
		if(result==0)
		{
			error.setCode("TRA2006");
			error.setDescription("Record not found");;
			saveMetaData(false,"CommitId is not found","2404");
			saveData(error, null);
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else
		{
			attendence=attendenceDAO.getAllRecords();		
			saveMetaData(true,"Record cleared successfully","2009");
			saveData(null, attendence);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
		
		
	}




private void saveResponse(Data data, MetaData metaData, Error errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}

private void saveData(Error erroDet, List<Attendance> attendances) {
	response.setError(erroDet);
	if(attendances!=null)
		data.setOutput(new ArrayList<Object>(attendances));
	

}

private void saveMetaData(boolean success, String description, String responseId) {
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}
	
	
	
	
	
	
	
}
