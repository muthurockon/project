package com.csr.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.bean.UserDetail;

public class UserDetailsMapper implements RowMapper<UserDetail> {

	public UserDetail mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserDetail userDetail=new UserDetail();
		userDetail.setCommitId(resultSet.getString(1));
		userDetail.setUserName(resultSet.getString(2));
		userDetail.setPersonalEmail(resultSet.getString(3));
		userDetail.setPhoneNumber(resultSet.getString(4));
		userDetail.setLocation(resultSet.getString(5));
		return userDetail;
	
	}

}
