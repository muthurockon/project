package com.csr.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.csr.bean.Location;
import com.csr.bean.User;
import com.csr.rowmapper.LocationMapper;
import com.csr.rowmapper.UserMapper;
import com.dateformatter.FormatDate;

@Component
public class UserDAO extends JdbcDaoSupport{
	
	DataSource dataSource;
	@Autowired
	public UserDAO(DataSource dataSource) {
	
		
		setDataSource(dataSource);
	
	}
	public List<User> getAllRecords()
	{
		String sql="select * from T_CSR_USER";
	List<User> ls=getJdbcTemplate().query(sql,new Object[]{}, new UserMapper());
	return ls;
	}

	public User getRecordById(String commitId)
	{
		User user=null;
		String sql="select * from T_CSR_USER where commitId=?";
		try{
		 user=getJdbcTemplate().queryForObject(sql, new Object[]{commitId}, new UserMapper());
		}
		catch(Exception e)
		{
			user=null;
		}
		
		return user;
	}
	public int createUserRecord(User value)
	{
		int a=0;
		String sql="insert into T_CSR_USER values(?,?,?,?,?,?)";
         if(value.getDeignation().equalsIgnoreCase("GET") || value.getDeignation().equalsIgnoreCase("TRAINEE"))
        	 value.setWeeksPending(12);
         else
        	 value.setWeeksPending(3);
         try{
        	 a=getJdbcTemplate().update(sql,new Object[]{value.getCommitId(),value.getInautixEmail(),value.getLocationAssigned(),value.getDeignation(),FormatDate.parse(value.getDateOfJoining()),value.getWeeksPending()});
         }
         catch(Exception e)
         {
        	 e.printStackTrace();
        	 a=-1;
         }
		return a;
	}
	public int updateUserRecord(String id,User user)
	{	
		int result=0;
		String sql="update T_CSR_USER set locationAssigned=?,designation=?,weeksPending=? where commitId=?";
		try
		{
			result=getJdbcTemplate().update(sql,new Object[]{user.getLocationAssigned(),user.getDeignation(),user.getWeeksPending(),id});
		}
		catch(Exception e)
		{
			result=0;
		}
		return result;
	}
	
	public int deleteUserRecord(String commitId)
	{

		int result=0;
		String sql="delete from T_CSR_USER where commitID=?";
		try
		{
			result=getJdbcTemplate().update(sql,new Object[]{commitId});
			//result=1;
		}
		catch(Exception e)
		{
			result=0;
		}
		return result;
	}
	
	public List<Location> getRecordByDate(String date)
	{
		List<Location> users=null;
		
		String sql="select T_CSR_USER.commitId,inautixEmail,locationAssigned,designation,dateofjoining,weeksPending,location from T_CSR_USER inner join T_CSR_USER_DETAIL on T_CSR_USER.commitId=T_CSR_USER_DETAIL.commitId where  dateofjoining=? and locationAssigned is null";
		try{
		 users=getJdbcTemplate().query(sql,new Object[]{FormatDate.parse(date)}, new LocationMapper());
		}
		catch(Exception e)
		{
			users=null;
		}
		System.out.println(users.size());
		return users;
	}
	public int updateLocationAssigned(Location location)
	{	
		int result=0;
		String sql="update T_CSR_USER set locationAssigned=?  where commitId=?";
		try
		{
			result=getJdbcTemplate().update(sql,new Object[]{location.getLocationAssigned(),location.getCommitId()});
		}
		catch(Exception e)
		{
			result=0;
		}
		return result;
	}
	public int updateWeeksPending(String id)
	{	
		int result=0;
		
		
		try
		{
			User new_user=getRecordById(id);
			int temp=new_user.getWeeksPending();
			if(temp!=0)
				temp--;
             System.out.println(temp);
             new_user.setWeeksPending(temp);
			String sql="update T_CSR_USER set weeksPending=? where commitId=?";
			   
			result=getJdbcTemplate().update(sql,new Object[]{new_user.getWeeksPending(),new_user.getCommitId()});
			System.out.println(result);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			result=0;
			System.out.println(result);

		}
		return result;
	}
}
