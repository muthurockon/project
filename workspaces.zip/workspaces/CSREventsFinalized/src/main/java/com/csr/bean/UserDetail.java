package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

public class UserDetail {
	@ApiModelProperty(position = 1, required = true, value = "Holds the commitId")
	String commitId;
	@ApiModelProperty(position = 2, required = true, value = "Holds the name")
	String userName;
	@ApiModelProperty(position = 3, required = true, value = "Holds the emailId")
	String personalEmail;
	@ApiModelProperty(position = 4, required = true, value = "Holds the phoneNumber")
	String phoneNumber;
	@ApiModelProperty(position = 5, required = true, value = "Holds the location")
	String location;
	
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPersonalEmail() {
		return personalEmail;
	}
	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

	

}
