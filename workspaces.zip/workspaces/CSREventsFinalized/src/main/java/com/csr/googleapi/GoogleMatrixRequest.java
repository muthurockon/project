package com.csr.googleapi;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.csr.dataaccess.PlaceDAO;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

public class GoogleMatrixRequest {

	@Autowired
	PlaceDAO places;
	private static final String API_KEY = "AIzaSyCOF25b88Hv3CdXMkfjtXAoK9aokmkrbW0";

	  OkHttpClient client;
	  public  GoogleMatrixRequest()
	  {
		  client = new OkHttpClient();
		  
	  }

	  public String run(String url) throws IOException {
	    Request request = new Request.Builder()
	        .url(url)
	        .build();

	    Response response = client.newCall(request).execute();
	    return response.body().string();
	  }
	  
	  public String formatParam(String param)
	  {
		  return param.replaceAll("\\s", "+");
		  
	  }
	 public String getPlace(String source,String destination) throws IOException {
		  System.setProperty("https.proxyHost", "proxy.pershing.com");
			System.setProperty("https.proxyPort", "8080");
	    
	    String url_request = "https://maps.googleapis.com/maps/api/distancematrix/json?origins="+source+"&destinations="+destination+"&key=" + API_KEY;

	    String response = run(url_request);
	  //  System.out.println(response);
	   return response;
	   
	  }

}
