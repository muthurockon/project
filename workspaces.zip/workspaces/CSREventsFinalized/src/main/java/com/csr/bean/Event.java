package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

public class Event {
	
	@ApiModelProperty(position = 1, value = "ID given to a event", dataType="Integer")
	private int eventId;
	@ApiModelProperty(position = 2, value = "eventName: The name of the event", dataType="java.lang.String")
	private String eventName;
	@ApiModelProperty(position = 3, value = "placeId: The place where event is conducted", dataType="Integer")
	private int placeId;
	@ApiModelProperty(position = 4, value = "description: The description of the event", dataType="java.lang.String")
	private String description;
	@ApiModelProperty(position = 5, value = "eventDate: The date of event", dataType="java.lang.String")
	private String eventDate;
	@ApiModelProperty(position = 6, value = "eventLead: The coordinator of the event", dataType="java.lang.String")
	private String eventLead;
	
	public int getPlaceId() {
		return placeId;
	}
	
	
	public int getEventId() {
		return eventId;
	}


	public void setEventId(int eventId) {
		this.eventId = eventId;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}


	public String getEventLead() {
		return eventLead;
	}


	public void setEventLead(String eventLead) {
		this.eventLead = eventLead;
	}
	
	
	
}
