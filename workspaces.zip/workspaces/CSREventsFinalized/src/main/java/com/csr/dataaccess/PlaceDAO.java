package com.csr.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.csr.bean.Place;
import com.csr.rowmapper.PlaceRowMapper;

@Component
public class PlaceDAO extends JdbcDaoSupport{
	@Autowired
	public PlaceDAO(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	
	public  int makePlaceEntry(Place place)
	{
		int result = 0;
		int count=0;
		/*if(place.getContactNumber().matches("[0-9]+"));
		else
		{
			return -2;
		}
		if(place.getName().matches("[a-zA-Z\\s]+"));
		else
		{
			return -3;
		}*/
	
		Place p=getPlaceByName(place.getName());
		if(p!=null)return -1;
		String sql="insert into T_CSR_Places values(?,?,?,?,?)";
		count=getKeyValue();
		Object param[] = {count,place.getName(),place.getAddress(),place.getLocation(),place.getContactNumber() };
		try{
			result = getJdbcTemplate().update(sql, param);
			result=1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return -1;
		}
		System.out.println(result);
		return result;
	}
	public List<Place> getAllRegisteredPlaces() {
		String sql="select * from T_CSR_Places";
        List<Place> placeList = getJdbcTemplate().query(sql, new Object[] {}, new PlaceRowMapper());
        return placeList;
	}
	public int update(int placeId,Place place)
	{
		int res;
		if(place.getContactNumber().matches("[0-9]+"));
		else
		{
			return -2;
		}
		if(place.getContactNumber().length()==10);
		else
		{
			return -4;
		}
		String SQL = "update T_CSR_Places set contactNumber=? where placeId=?";
		try{
	     res= getJdbcTemplate().update(SQL,new Object[]{place.getContactNumber(),placeId});
		}
		catch(Exception e)
		{
			return -5;
		}
	    return res;
	}

public int delete(int placeId)
       {
              int res,userRes,eventRes;
              System.out.println("in");
              String SQL = "delete from T_CSR_Places  where placeId=?";
              String userSql="update T_CSR_USER set locationAssigned=NULL where locationAssigned=?";
              String eventSql="delete from T_CSR_Events  where placeId=?";
              try{
                     res= getJdbcTemplate().update(SQL,new Object[]{placeId});
                     userRes=getJdbcTemplate().update(userSql,new Object[]{String.valueOf(placeId)});
                     eventRes=getJdbcTemplate().update(eventSql,new Object[]{placeId});
              }
              catch(Exception e)
              {
                     return -1;
              }
         System.out.println(res+" "+userRes+" "+eventRes);
           return res;
       }


public int getKeyValue()
{
	//select count(movieId) from T_XBBNHBE_movie
	String sql="select max(placeId) from T_CSR_Places";
	int count=0;
	try
	{
		count=  getJdbcTemplate().queryForObject(sql,new Object[]{},Integer.class);
		count++;
		System.out.println(count);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		if (e instanceof EmptyResultDataAccessException) 
			return 1;
		else if(e instanceof NullPointerException)
			return 1;
	}
	System.out.println(count);
	return count;
}

	public Place getPlaceByName(String name) {
		// TODO Auto-generated method stub
		Place place=null;
		String sql="SELECT * from T_CSR_Places where name=?";
		try
		{
		place = (Place) getJdbcTemplate().queryForObject(sql, new Object[] {name},new PlaceRowMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return null;
		}
		        return place;
	}
	public int getPlaceByLoaction(String location) {
		// TODO Auto-generated method stub
		Place place=null;
		String sql="SELECT * from T_CSR_Places where lower(loaction)=?";
		try
		{
			place = (Place) getJdbcTemplate().queryForObject(sql, new Object[] {location.toLowerCase()},new PlaceRowMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return -1;
		}
		        return place.getPlaceId();
	}
	public Place getPlaceById(int placeId) {
		// TODO Auto-generated method stub
		Place place=null;
		String sql="SELECT * from T_CSR_Places where placeId=?";
		try
		{
			place = (Place) getJdbcTemplate().queryForObject(sql, new Object[] {placeId},new PlaceRowMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return null;
		}
		return place;
	}
	public List<String> getUniqueLocations()
	{
		String sql="SELECT distinct loaction from T_CSR_Places";
		List<String> placeList=getJdbcTemplate().queryForList(sql, String.class);
		System.out.println(placeList.size()+"i dao");
		return placeList;
	}
}
