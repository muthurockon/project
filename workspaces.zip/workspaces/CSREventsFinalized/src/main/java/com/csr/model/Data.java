package com.csr.model;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import org.springframework.stereotype.Component;

import com.csr.bean.Place;

@Component
public class Data {

	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<Object> output;

	public List<Object> getOutput() {
		return output;
	}

	public void setOutput(List<Object> output) {
		this.output = output;
	}

}
