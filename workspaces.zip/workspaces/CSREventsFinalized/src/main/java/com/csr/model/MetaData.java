package com.csr.model;
import io.swagger.annotations.ApiModelProperty;

import org.springframework.stereotype.Component;

@Component
public class MetaData {
	@ApiModelProperty(position = 2, required = true, value = "Describes the generated result :description ")
	private String description;
	@ApiModelProperty(position = 1, required = true, value = "Response ID for the generated result :responseId ")
	private String responseId;
	@ApiModelProperty(position = 3, required = true, value = "A boolean value that represents success or failure:success ")
	private boolean success;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getResponseId() {
		return responseId;
	}
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}
	public boolean getSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
}
