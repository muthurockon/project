package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

public class Place {

	@ApiModelProperty(position = 1, value = "placeId: The plcae ID of the plcae", dataType="Integer")
	private int placeId ;
	@ApiModelProperty(position = 2, value = "name: The name of the place", dataType="java.lang.String")
	private String name ;
	@ApiModelProperty(position = 3, value = "address: The address ", dataType="java.lang.String")
	private String address ;
	@ApiModelProperty(position = 4, value = "loaction: The email ID of the user", dataType="java.lang.String")
	private String location;
	@ApiModelProperty(position = 5, value = "contactNumber: The email ID of the user", dataType="java.lang.String")
	private String contactNumber ;
	
	public int getPlaceId() {
		return placeId;
	}
	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
}
