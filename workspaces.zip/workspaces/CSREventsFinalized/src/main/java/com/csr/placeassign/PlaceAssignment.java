package com.csr.placeassign;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.csr.bean.Location;
import com.csr.dataaccess.PlaceDAO;
import com.csr.dataaccess.UserDAO;
import com.csr.googleapi.GoogleMatrixRequest;

public class PlaceAssignment {

	@Autowired
	PlaceDAO places;
	@Autowired
	UserDAO users;
	
	
	public PlaceAssignment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static int getLeastDistIndex(List<Long> distList)
	{
		  int i;
		  Long min=new Long(0);
		  int index=0;
		  for(i=0;i<distList.size();i++)
		  {
			  Long value= distList.get(i);
			  if(min==0 || value<min)
			  {
				  min=value;
				  index=i;
			  }
		  }
		  return index;
	}
	public String combinePlaces(List<String> destPlace)
	{
		String destination="";
		int i;
		for(i=0;i<destPlace.size();i++)
		{
			destination+=destPlace.get(i)+"+%7C";
		}
		//System.out.println(destination);
		int index=destination.lastIndexOf("+%7C");
		destination=destination.substring(0,index);
		destination=destination.replaceAll("\\s", "+");
		return destination;
	}
	public String assignLoaction(Location userDetails,List<String> destPlace)
	{
		//System.out.println("In func");
		GoogleMatrixRequest request=new GoogleMatrixRequest();
		String destination=combinePlaces(destPlace);
		//System.out.println(destination);
		String response=null;
		try {
			response = request.getPlace(userDetails.getLocation(), destination);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 JSONObject obj = new JSONObject(response);
		   // String out=""+obj.getJSONArray("rows").getJSONObject(0).getJSONArray("elements").getJSONObject(0).getJSONObject("distance").getLong("value");
		    JSONArray jsonarray=obj.getJSONArray("rows").getJSONObject(0).getJSONArray("elements");
		    JSONArray destAddress=obj.getJSONArray("destination_addresses");
		    int i;
		    List<Long> distList=new ArrayList();
		    for(i=0; i<jsonarray.length();i++)
		    {
		    	JSONObject jsonobject = jsonarray.getJSONObject(i);
		    	Long dist=jsonobject.getJSONObject("distance").getLong("value");
		    	distList.add(dist);
		    //	System.out.println(dist);
		    }
		  //  System.out.println(response);
		    int leastDistIndex= getLeastDistIndex(distList);
		  //  System.out.println("Place:"+ destAddress.getString(leastDistIndex)+" Dist="+distList.get(leastDistIndex)+" index="+leastDistIndex);
		   // System.out.println(out);
		   int lastIndex=destAddress.getString(leastDistIndex).indexOf(",");
		   String finalLacation=destAddress.getString(leastDistIndex).substring(0,lastIndex);
		 //  System.out.println(finalLacation);
		   return finalLacation;
	}
	
}
