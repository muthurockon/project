package com.csr.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.csr.bean.Event;
import com.csr.bean.Location;
import com.csr.bean.Place;
import com.csr.bean.User;
import com.csr.dataaccess.PlaceDAO;
import com.csr.dataaccess.UserDAO;
import com.csr.mail.MailService;
import com.csr.model.Data;
import com.csr.model.Error;
import com.csr.model.MetaData;
import com.csr.model.Response;
import com.csr.placeassign.PlaceAssignment;

@EnableSwagger2
@RestController
public class UserController {

	@Autowired
	UserDAO userDAO;
	
	@Autowired
	PlaceDAO placeDAO;
@Autowired
MetaData metaData;
@Autowired
Data data;
@Autowired
Response response;
@Autowired
Error error;
@ApiOperation(value="retrive the User record using Get method",notes="returns all  the User record")
@ApiResponses(value={  @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
@RequestMapping(value="/users",method=RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> display()
{
	System.out.println("in");
		List<User> user;
		user=userDAO.getAllRecords();
          if(user.isEmpty())
          {
        	 error.setCode("CSR_USR2007");
      		error.setDescription("No User is present in the table");
      		saveMetaData(false,"Record not found","2001");
      		saveResponse(null,metaData,error);
      		return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;  
          }
          else
          {
        	  saveMetaData(true,"Records found","2008");
        	  saveData(null, user);
        	  saveResponse(data,metaData, null);
        	  return new ResponseEntity<Response>(response, HttpStatus.OK);
          }
}








@ApiOperation(value="retrive the specific user record using Get method",notes="returns the user data with  commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/users/{commitId}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displaySingle(@ApiParam(value = "object that need to be displayed", required = true) @PathVariable("commitId") String new_bookId) 
{	
		List<User> users = new ArrayList<User>();	

			User user = userDAO.getRecordById(new_bookId);
			 if(user==null)
				{
					saveMetaData(false,"User not registered","2008");
					error.setCode("CSR_USR2001");
					error.setDescription("Invalid ID");
//					saveData(errorDetails, null);
					saveResponse(null,metaData, error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				}
				else
				{
					users.add(user);
					saveMetaData(true,"Data found","2005");
					saveData(null, users);
					saveResponse(data,metaData, null);
					return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
				}
			
	
			// TODO Auto-generated catch block
			
			/*error.setCode("CSR_USR2002");
			if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if( e instanceof DataAccessException)
				error.setDescription("Database error");
			
			else if(e instanceof InvalidActivityException)
				error.setDescription("Invalid ID  should not be .");
			else
				error.setDescription("commitId not found");;
			saveMetaData(false,"Invalid enrty/type","2009");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, error);
			//return response;
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;*/
			
			
	
}
















@ApiOperation(value="creates the User record using Post method",notes="Register a new user")
@ApiResponses(value={ @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
@ResponseStatus(HttpStatus.ACCEPTED)



@RequestMapping(value="/users",method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> insert(@RequestBody User usr)
{
	List<User> users = new ArrayList<User>();
	ResponseEntity<Response> res=null;
	int result=0;
		result=userDAO.createUserRecord(usr);	
		System.out.println(result);
		if(result==1){
			users.add(usr);			
			saveMetaData(true,"User record created","201");
			saveData(null, users);
			saveResponse(data,metaData, null);
			res= new ResponseEntity<Response>(response, HttpStatus.OK);
		}
		else if(result==-1)
		{
			error.setCode("CSR_USR2003");
			error.setDescription("Error inserting user data");
			saveMetaData(false,"Unique constraint violated. Commit ID already present","2008");
			saveResponse(null,metaData, error);
			res= new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
		return res;
		
		
	}
	
	


@ApiOperation(value="update the User record using Put method",notes="update the user data with commitID as reference")
@ApiResponses(value={
		@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),   
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),   
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), 
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/users/{commitId}",method=RequestMethod.PUT,produces={MediaType.APPLICATION_JSON_VALUE},consumes=MediaType.APPLICATION_JSON_VALUE
)


public ResponseEntity<Response> put(@ApiParam(value = "object that need to be updated", required = true)@PathVariable(value="commitId") String commitId,@RequestBody User new_user)
{
	List<User> users = new ArrayList<User>();
	int result=0;
	
		if(commitId==null)
			throw new NullPointerException();
		
		result=userDAO.updateUserRecord(commitId, new_user);	
		if(result==0)
		{
			error.setCode("CSR_USR2005");
			error.setDescription("Invalid ID");;
			saveMetaData(false,"Id not found","2404");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else{
			//Book book=bookDao.selectSingle(bookId);
			users.add(new_user);		
			saveMetaData(true,"The following record is successfully updated","2008");
			saveData(null, users);
			saveResponse(data,metaData,null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);	
	}
}

@ApiOperation(value="delete the user record using delete method",notes="delete the user data with commitId as reference")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),  
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class),
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/users/{commitID}",method=RequestMethod.DELETE,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> delete(@ApiParam(value = "object that need to be deleted", required = true)@PathVariable(value="commitID") String commitId)
{
	List<User> users = new ArrayList<User>();
	int result=0;
		result=userDAO.deleteUserRecord(commitId);
		if(result==0)
		{
			error.setCode("CSR_USR2006");
			error.setDescription("Record not found");
			saveMetaData(false,"User ecord to be deleted not found","2404");
			saveData(error, null);
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else	
		{	
			saveMetaData(true,"Successfully deleted","2009");
			saveData(null, users);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
}




@ApiOperation(value="retrive the specific user record using Get method",notes="returns the user data with  commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/records-view/{dateOfJoining}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displayAllDateNotNull(@ApiParam(value = "object that need to be displayed", required = true) @PathVariable("dateOfJoining") String dateOfJoining) 
{	
	System.out.println("in cont");
	
		//Getting unfilled loactions
		List<Location> userDetails=new ArrayList();
		userDetails=userDAO.getRecordByDate(dateOfJoining);
		
		
		//List of all places
		/*List<String> destPlaces=new ArrayList();
		destPlaces= placeDAO.getUniqueLocations();	
		System.out.println(destPlaces.size());*/
		
		//Call googleAPI 1st level call
	//	assignPlace(userDetails,destPlaces);
		
		
      if(userDetails.isEmpty())
      {
    	 error.setCode("CSR_USR2007");
  		error.setDescription("No User is present in the table");
  		saveMetaData(false,"Record not found","2001");
  		saveResponse(null,metaData,error);
  		return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;  
      }
      else
      {
    	  saveMetaData(true,"Records found","2008");
    	  saveData(null, userDetails);
    	  saveResponse(data,metaData, null);
    	  return new ResponseEntity<Response>(response, HttpStatus.OK);
      }
      
}





@ApiOperation(value="retrive the specific user record using Get method",notes="returns the user data with  commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/records/{dateOfJoining}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displayAllDate(@ApiParam(value = "object that need to be displayed", required = true) @PathVariable("dateOfJoining") String dateOfJoining) 
{	
	System.out.println("in cont");
	
		//Getting unfilled loactions
		List<Location> userDetails=new ArrayList();
		userDetails=userDAO.getRecordByDate(dateOfJoining);
		
		
		//List of all places
		List<String> destPlaces=new ArrayList();
		destPlaces= placeDAO.getUniqueLocations();	
		System.out.println(destPlaces.size());
		
		//Call googleAPI 1st level call
		assignPlace(userDetails,destPlaces);
		
		
		
      if(userDetails.isEmpty())
      {
    	 error.setCode("CSR_USR2007");
  		error.setDescription("No User is present in the table");
  		saveMetaData(false,"Record not found","2001");
  		saveResponse(null,metaData,error);
  		return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;  
      }
      else
      {
    	  saveMetaData(true,"Records found","2008");
    	  saveData(null, userDetails);
    	  saveResponse(data,metaData, null);
    	  return new ResponseEntity<Response>(response, HttpStatus.OK);
      }
      
}


public void initiateMail(List<Location> userDetails,int placeId, String loc)
{
	MailService mailService=new MailService();
	Place place=placeDAO.getPlaceById(placeId);
	String messageSubject="CSR Place assignment-Regd.";
	String messageText="Hi, \n     You have been assigned nearest location based your residing location "+loc+" The place to go is "+place.getName()+" . \n Full address:"+place.getAddress();
	messageText+=".\n Short location: "+place.getLocation()+".\nThis message is sent with high importance";
	messageText.replaceAll("\n", System.getProperty("line.separator"));
//	messageText+="Short address is "+place.getLocation();
	try {
		mailService.sendMail(userDetails, messageSubject, messageText);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(messageText);
}

private void assignPlace(List<Location> userDetails,List<String> destPlaces)
{
	int i=0;
	PlaceAssignment placeAssignment=new PlaceAssignment();
	//initiateMail(userDetails,7);

	for(i=0;i<userDetails.size();i++)
	{
		String location=placeAssignment.assignLoaction(userDetails.get(i),destPlaces);
		int placeId=placeDAO.getPlaceByLoaction(location.trim());
		System.out.println("UserName="+userDetails.get(i).getCommitId()+" Username="+ userDetails.get(i).getInautixEmail()+" loc="+userDetails.get(i).getLocation()+"Loc="+location+"PlaceId="+placeId);
		userDetails.get(i).setLocationAssigned(String.valueOf(placeId));
		userDAO.updateLocationAssigned(userDetails.get(i));
		initiateMail(userDetails,placeId,userDetails.get(i).getLocation());
	}
}


@ApiOperation(value="retrive the specific user record using Get method",notes="returns the user data with  commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
@RequestMapping(value="/attendence-records",method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
public void sendAttendence(@RequestBody List<String> attendence)
{
	for(String commitId :attendence)
	{
		int result=userDAO.updateWeeksPending(commitId);
		if(result==1)
		{
			System.out.println("done");
		}
	}		
}


private void saveResponse(Data data, MetaData metaData, Error errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}

private void saveData(Error erroDet, List user) {
	response.setError(erroDet);
	//List<Object> userList=new ArrayList<Object>(testObj);
	if(user!=null)
	data.setOutput(new ArrayList<Object>(user));

}

private void saveMetaData(boolean success, String description, String responseId) {
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}
}
