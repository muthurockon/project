package com.csr.dataaccess;

import java.sql.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.csr.bean.Event;
import com.csr.bean.User;
import com.csr.rowmapper.EventRowMapper;
import com.csr.rowmapper.UserMapper;
import com.dateformatter.FormatDate;

@Component
public class EventDAO extends JdbcDaoSupport {
	@Autowired
	public EventDAO(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	
	public  int createEvent(Event event)
	{
		int result = 0;
		int count=0;
		/*if(user.getMobile().matches("[0-9]+"));
		else
		{
			return -2;
		}
		if(user.getUserName().matches("[a-zA-Z]+"));
		else
		{
			return -3;
		}*/
		String sql="insert into T_CSR_Events values(?,?,?,?,?,?)";
		count=getEventKey();
		System.out.println(event.getEventDate());
		
		Object param[] = {count,event.getEventName(),event.getPlaceId(),event.getDescription(),FormatDate.parse(event.getEventDate()),event.getEventLead()};
		try{
			result = getJdbcTemplate().update(sql, param);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return -1;
		}
		return result;
	}
	public List<Event> getAllEvents() {
		String sql="select * from T_CSR_Events";
        List<Event> eventList = getJdbcTemplate().query(sql, new Object[] {}, new EventRowMapper());
        return eventList;
	}
	/*public int update(String phone,Place place)
	{
		int res;
		if(phone.matches("[0-9]+"));
		else
		{
			return -2;
		}
		if(user.getUserName()==null)return -5;
		if(user.getUserName().matches("[a-zA-Z\\s]+"));
		else
		{
			return -3;
		}
		if(phone.length()==10);
		else
		{
			return -4;
		}
		String SQL = "update T_XBBNHBE_USER set name=? where phone=?";
		try{
	     res= getJdbcTemplate().update(SQL,new Object[]{user.getUserName(),phone});
		}
		catch(Exception e)
		{
			return -5;
		}
	    return res;
	}*/
	public int delete(int eventId)
	{
		int res;
		String SQL = "delete from T_CSR_Events  where eventId=?";
		try{
			res= getJdbcTemplate().update(SQL,new Object[]{eventId});
		}
		catch(Exception e)
		{
			return -5;
		}
	   
	    return res;
	    
	}

	public int getEventKey()
	{
		//select count(movieId) from T_XBBNHBE_movie
		String sql="select max(eventId) from T_CSR_Events";
		int count=0;
		try
		{
			count=  getJdbcTemplate().queryForObject(sql,new Object[]{},Integer.class);
			count++;
		}
		catch(Exception e)
		{
			if (e instanceof EmptyResultDataAccessException) 
				return 1;
			else if(e instanceof NullPointerException)
				return 1;
				
		}
		return count;
	}

	public Event getEventByName(String name) {
		// TODO Auto-generated method stub
		Event event=null;
		String sql="SELECT eventId from T_CSR_Events where eventName=?";
		try
		{
			event = (Event) getJdbcTemplate().queryForObject(sql, new Object[] {name},new EventRowMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return null;
		}
		        return event;
	}
	public List<User> getEventByPlaceId(int placeId) {
		// TODO Auto-generated method stub
         List<User> users;
		String sql="SELECT * from T_CSR_USER where locationAssigned =?";
		
			users = getJdbcTemplate().query(sql, new Object[] {String.valueOf(placeId)},new UserMapper());
		
		
		        return users;
	}
}
