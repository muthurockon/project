package com.csr.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import javax.activity.InvalidActivityException;
import javax.naming.NameNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.csr.bean.UserDetail;
import com.csr.dataaccess.UserDetailsDAO;
import com.csr.model.Data;
import com.csr.model.Error;
import com.csr.model.MetaData;
import com.csr.model.Response;
@EnableSwagger2
@RestController
public class UserDetailsController {
	@Autowired
	UserDetailsDAO userDetailsDAO;
@Autowired
MetaData metaData;
@Autowired
Data data;
@Autowired
Response response;
@Autowired
Error error;
@ApiOperation(value="retrive the userDetails record using Get method",notes="returns the userDetails data with commit id as reference")
@ApiResponses(value={  @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })
@RequestMapping(value="/user-details",method=RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> display()
{
		List<UserDetail> userDetails;
		userDetails=userDetailsDAO.select();
          if(userDetails.isEmpty())
          {
        	  error.setCode("TRA2007");
      		error.setDescription("No userDetails is present in the table");
      		saveMetaData(false,"Data not found in table","2001");
      		
      		saveResponse(null,metaData,error);
      		return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
        	  
          }
          else
          {
        	  saveMetaData(true,"found Successfully","2008");
        	  saveData(null, userDetails);
        	  saveResponse(data,metaData, null);
        	  return new ResponseEntity<Response>(response, HttpStatus.OK);
          }
}








@ApiOperation(value="retrive the specific userDetails record using Get method",notes="returns the userDetails data with commitId")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),    @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class) })

@RequestMapping(value="/user-details/{commitId}",method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> displaySingle(@ApiParam(value = "object that need to be displayed", required = true) @PathVariable("commitId") String commitId) 
{
		List<UserDetail> userDetails = new ArrayList<UserDetail>();
			UserDetail userDetail = userDetailsDAO.selectSingle(commitId);
			 if(userDetail==null)
				{
					saveMetaData(false,"commitId not found in table","2008");
					error.setCode("TRA2001");
					error.setDescription("Invalid ID");
//					saveData(errorDetails, null);
					saveResponse(null,metaData, error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				}
				else
				{
					userDetails.add(userDetail);
					saveMetaData(true,"successfully found","2005");
					saveData(null, userDetails);
					saveResponse(data,metaData, null);
					return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
				}
}
















@ApiOperation(value="posts the userDetails record using Post method",notes="register userDetails with commitId as reference")
@ApiResponses(value={ @ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),    @ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), @ApiResponse(code = 400, message = "Bad Request",response=Response.class), @ApiResponse(code = 201, message = "Created Response",response=Response.class) })
@ResponseStatus(HttpStatus.ACCEPTED)



@RequestMapping(value="/user-details",method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> insert(@RequestBody UserDetail userDetail)
{
	List<UserDetail> userDetails = new ArrayList<UserDetail>();
	int result=0;			
		result=userDetailsDAO.insert(userDetail);
		
		if(result==1){
			userDetails.add(userDetail);			
			saveMetaData(true,"Created","200");
			saveData(null, userDetails);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
		else
		{
			error.setCode("TRA2003");
			error.setDescription("userDetails not created");
			saveMetaData(false,"Invalid Type","2008");
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.CONFLICT);
		}
		
}


@ApiOperation(value="update the userDetails record using Put method",notes="update the userDetails data with commmit id as reference")
@ApiResponses(value={
		@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),   
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),   
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class), 
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/user-details/{commitId}",method=RequestMethod.PUT,produces={MediaType.APPLICATION_JSON_VALUE},consumes=MediaType.APPLICATION_JSON_VALUE
)


public ResponseEntity<Response> put(@ApiParam(value = "Commit ID of the object to be updated", required = true)@PathVariable(value="commitId") String commitId,@RequestBody UserDetail userDetail)
{
	List<UserDetail> userDetails = new ArrayList<UserDetail>();
	
		if(commitId==null)
			throw new NullPointerException();
		
		userDetail=userDetailsDAO.put(commitId, userDetail);	
	     
		if(userDetail==null)
		{
			error.setCode("TRA2005");
			error.setDescription("Invalid ID");;
			saveMetaData(false,"userDetails not found","2404");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else{
		
			//Book book=bookDao.selectSingle(bookId);
		userDetails.add(userDetail);		
		saveMetaData(true,"Successfully updated","2008");
		saveData(null, userDetails);
		saveResponse(data,metaData,null);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
}

@ApiOperation(value="deletes the userDetails record using delete method",notes="delete the userDetails data with commiID")
@ApiResponses(value={@ApiResponse(code = 200, message = "Successful Response",response=Response.class ),
		@ApiResponse(code = 404, message = "Invalid Information Sent",response=Response.class),  
		@ApiResponse(code = 500, message = "Internal Server Error",response=Response.class),
		@ApiResponse(code = 400, message = "Bad Request",response=Response.class),
		@ApiResponse(code = 406, message = "Not Acceptable",response=Response.class)})
@RequestMapping(value="/user-details/{commitID}",method=RequestMethod.DELETE,produces={MediaType.APPLICATION_JSON_VALUE})
public ResponseEntity<Response> delete(@ApiParam(value = "object that need to be deleted", required = true)@PathVariable(value="commitID") String commitId)
{
	List<UserDetail> userDetails = new ArrayList<UserDetail>();
		UserDetail userDetail=userDetailsDAO.delet(commitId);
		if(userDetail==null)
		{
			error.setCode("TRA2006");
			error.setDescription("Record not found");;
			saveMetaData(false,"Id is not found","2404");
			saveData(error, null);
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		}
		else	
		{
			userDetails.add(userDetail);			
			saveMetaData(true,"successfully deleted","2009");
			saveData(null, userDetails);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}
}
private void saveResponse(Data data, MetaData metaData, Error errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}

private void saveData(Error erroDet, List userDetails) {
	response.setError(erroDet);
	data.setOutput(new ArrayList<Object>(userDetails));

}

private void saveMetaData(boolean success, String description, String responseId) {
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}

}
