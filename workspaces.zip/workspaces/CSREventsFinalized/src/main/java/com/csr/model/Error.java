package com.csr.model;
 
import io.swagger.annotations.ApiModelProperty;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@Generated("org.jsonschema2pojo")
@XmlRootElement(name = "Errors")
@Component
public class Error {

	@ApiModelProperty(position =1, required = true, value = "Description of the Code:Error")
	private String code;
	@ApiModelProperty(position =2, required = true, value = "Description of the Error:Code")
	private String description;
	
	public Error() {
		super();
		
	}
	public Error(String code, String description) {
		super();
		this.code = code;
		this.description = description;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}