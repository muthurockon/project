package com.csr.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.csr.bean.Attendance;
import com.csr.rowmapper.AttendanceMapper;
@Component
public class AttendanceDAO extends JdbcDaoSupport {
	DataSource dataSource;
	@Autowired
	public AttendanceDAO(DataSource dataSource) {
	
		
		setDataSource(dataSource);
	
	}
	public List<Attendance> getAllRecords()
	{
		String sql="select * from T_CSR_ATTENDENCE";
		List<Attendance> attendence=getJdbcTemplate().query(sql,new Object[]{}, new AttendanceMapper());
		return attendence;
	}

	public List<Attendance> getByCommitId(String commitId)
	{
		List<Attendance> attendence=null;
		String sql="select * from T_CSR_ATTENDENCE where commitId=?";
		try{
		 attendence=getJdbcTemplate().query(sql, new Object[]{commitId}, new AttendanceMapper());
		}
		catch(Exception e)
		{
			attendence=null;
		}
		return attendence;
	}
	public int getByEventId(String eventId)
	{
		List<Attendance> attendence=null;
		int result=0;
		String sql="select * from T_CSR_ATTENDENCE where eventId=?";
		try{
		 attendence=getJdbcTemplate().query(sql, new Object[]{eventId}, new AttendanceMapper());
		}
		catch(Exception e)
		{
			attendence=null;
		}
		return attendence.size();
	}
	public int insert(Attendance value)
	{	
		String sql="insert into T_CSR_ATTENDENCE values(?,?,?)";
		int result=0;
		try
		{
			result=getJdbcTemplate().update(sql,new Object[]{value.getCommitId(),value.getEventId(),value.getComments()});
		}
		catch(Exception e)
		{
			return -1;
		}
		return result;
	}

	
	public int delete(String commitId)
	{
		String sql="select * from T_CSR_ATTENDENCE where commitId=?";
		Attendance attendence=new Attendance();
		int result=0;
		try
		{
			result = getJdbcTemplate().update("delete from T_CSR_ATTENDENCE where commitId=?", new Object[]{commitId});
		}
		catch(Exception e)
		{
			result=-1;
		}
		return result;
	}


}
