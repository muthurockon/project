package com.csr.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.csr.bean.Place;

public class PlaceRowMapper implements RowMapper {
    public Place mapRow(ResultSet rs, int rowNum) throws SQLException {

        // TODO Auto-generated method stub      

        Place place=new Place(); 
        place.setPlaceId(rs.getInt("placeId"));
        place.setName(rs.getString("name"));
        place.setAddress(rs.getString("address"));
        place.setLocation(rs.getString("loaction"));
        place.setContactNumber(rs.getString("contactNumber"));
        return place;

    }
}
