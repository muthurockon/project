package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

public class Location {
	
	@ApiModelProperty(position = 1, required = true, value = "Holds the commitId")
	String commitId;
	@ApiModelProperty(position = 2, required = true, value = "Holds the emailId")
	String inautixEmail;
	@ApiModelProperty(position = 3, required = true, value = "Holds the Assigned location")
	String locationAssigned;
	@ApiModelProperty(position = 4, required = true, value = "Holds the designation")
	String deignation;
	@ApiModelProperty(position = 5, required = true, value = "Holds the dateOfJoining")
	String dateOfJoining;
	@ApiModelProperty(position = 6, required = true, value = "Holds the weakPending")
	int WeeksPending;
	@ApiModelProperty(position = 5, required = true, value = "Holds the location")
	String location;
	
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	public String getInautixEmail() {
		return inautixEmail;
	}
	public void setInautixEmail(String inautixEmail) {
		this.inautixEmail = inautixEmail;
	}
	public String getLocationAssigned() {
		return locationAssigned;
	}
	public void setLocationAssigned(String locationAssigned) {
		this.locationAssigned = locationAssigned;
	}
	public String getDeignation() {
		return deignation;
	}
	public void setDeignation(String deignation) {
		this.deignation = deignation;
	}
	
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public int getWeeksPending() {
		return WeeksPending;
	}
	public void setWeeksPending(int weeksPending) {
		WeeksPending = weeksPending;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
