package com.csr.bean;

import io.swagger.annotations.ApiModelProperty;

public class AttendenceRecord {

	String commitId;
	String comments;
	@ApiModelProperty(position = 2, value = "eventName: The name of the event", dataType="java.lang.String")
	private String eventName;
	@ApiModelProperty(position = 4, value = "description: The description of the event", dataType="java.lang.String")
	private String description;
	@ApiModelProperty(position = 5, value = "eventDate: The date of event", dataType="java.lang.String")
	private String eventDate;
	@ApiModelProperty(position = 6, value = "eventLead: The coordinator of the event", dataType="java.lang.String")
	private String eventLead;
}
