package com.csr.model;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModelProperty;


@Component
public class Response {
	@ApiModelProperty(position =1, required = true, value = "Description of the metadata that has description, success indicator:MetaData")
	private MetaData metaData;
	@ApiModelProperty(position = 2, required = true, value = "The data to be returend by the API:Data")
	private Data data;
	@ApiModelProperty(position = 3, required = true, value = "The error generated for a particular request if any:Error")
	private Error error;
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public Error getError() {
		return error;
	}
	public void setError(Error error) {
		this.error = error;
	}

}
