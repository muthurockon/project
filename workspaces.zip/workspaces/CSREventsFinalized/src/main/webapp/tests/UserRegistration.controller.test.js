describe('registerUserController', function () {  
  
  
   beforeEach(module('myApp'));  
  
  
   var $controller;  
 
  
   beforeEach(inject(function(_$controller_){  
  $controller = _$controller_;  
   }));  
     
  describe('registerUserController', function () {  
  
  it('Check Given Number Is A Whole Number', function () {  
     var $scope = {};  
	    var finalOne = {
            "eventName": 'Thalapathy',
            "placeId": '15',
            "description": 'Important',
            "eventDate": 'someday',
            "eventLead": 'Great'
        };
/*   var controller = $controller('registerUserController', { $scope: $scope });  
  expect($scope.getValue()).toEqual(finalOne);  
  });   */
 var controller = $controller('registerUserController', { $scope: $scope });  
  expect($scope.getById('15')).toEqual(finalOne);  
  });   
 
  });  
  
  
  });  