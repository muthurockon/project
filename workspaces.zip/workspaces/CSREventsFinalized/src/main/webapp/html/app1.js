angular.module("myApp").controller("displayController",function($scope,$http,$window){
	
	$scope.status="cont";
$scope.retrieve=function()
{
	$scope.status="in";
	$http.get("http://172.24.18.155:8080/CSREvent/places").then(function(response){
		$scope.status="in1";
		$scope.places=response.data.data.output;
	},function(response){
		$scope.status="in2";
		$scope.error=response.statusText;
	})
}
});