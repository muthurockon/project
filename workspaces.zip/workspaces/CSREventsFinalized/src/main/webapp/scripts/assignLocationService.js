/**
 * 
 */
var app=angular.module("myApp");

app.factory('recordDisp',function($http){
	return {
		getRecordDisp :function(dateofJoining)
	{
			return  $http({ 
                  method: 'GET',
                  url:'http://localhost:8080/CSREvent/records-view/'+dateofJoining
                 
               })
	}
}
});
app.factory('assignLocation',function($http){
	return {
		getAssignLocation :function(dateofJoining)
	{
			return $http({ 
                 method: 'GET',
                 url:'http://localhost:8080/CSREvent/records/'+dateofJoining
                
              });
	}
}
});
