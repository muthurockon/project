/**
 * 
 */

var app=angular.module("myApp");

app.factory('attendenceDetails',function($http){
	return {
		getAttendence :function(jdata)
	{
		return $http({

            method:'POST',

            url : 'http://localhost:8080/CSREvent/attendence-records',
            
            data: jdata,
            headers:{

                "Content-Type":"application/json"

        }

	});
	}
}
});
