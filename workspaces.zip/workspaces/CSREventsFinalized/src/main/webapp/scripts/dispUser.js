/**
 * 
 */
angular.module("myApp").controller('dispAllUser',function($scope,$http,dispUser){
                $scope.view=false;
               
                console.log("Inside controller");
                
                    $scope.view=!$scope.view;
                    dispUser.getDispUser().then(function(response){
                     console.log("Success message")
                     $scope.users=response.data.data.output;
                     
                     $scope.view=true;
                 },function(response) {
                     window.alert('No users found');
                 });
                    
                $scope.orderByThis=function(x)
                {
                	$scope.order=x;
                }
                 $scope.users={};
                 $scope.userDetails={};
                
            });