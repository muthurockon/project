/**
 * 
 */
angular.module("myApp").controller("eventRegistraton",function($scope,$http,$window,$filter,place,insertEvent){
	
	$scope.status="cont";
$scope.retrieve=function()
{
	$scope.status="in";
	place.getPlace().then(function(response){
		$scope.status="in1";
		$scope.places=response.data.data.output;
	},function(response){
		$scope.status="in2";
		$scope.error=response.statusText;
	})
	  $scope.myClick=function(eveName,desp,eveDate,eveLead){
	

		var index=$scope.selectedPlaceId.indexOf(",");
		var placeId=$scope.selectedPlaceId.substring(0,index);
	

	      var a = $filter('date')(eveDate, "MM-dd-yyyy");

	        var data={
	        		eventName:eveName,
	        		placeId:placeId,
	        	    description: desp,
	        	   eventDate:a,
	        	   eventLead:eveLead,
	        			
	          
	        };

	
	        var jdata = JSON.stringify(data);
	        

	                  window.alert(jdata);    
	         
	        
	                  insertEvent.setInsertEvent(jdata).then(function(response){
	           
	         $scope.message="Inserted Successfully";
	        
	        //  $window.location.href = '/user';
	        // $location.path('/user');
	       },function(response) {
	         window.alert('No users found');
	         
	      });
	          
	    }
}
});