angular.module("myApp").controller("displayController",function($scope,$http,place,deletePlace){
	
	$scope.status="cont";
	place.getPlace().then(function(response){
		window.alert(response.data);
		$scope.status="in1";
		$scope.places=response.data.data.output;
		
	},function(response){
		$scope.status="in2";
		$scope.error=response.statusText;
		
	});
	$scope.deletePlace=function(placeId)
    {
                    window.alert(placeId);
                    deletePlace.getDelPlace(placeId).then(function(response){
                                    window.alert("Success");
                                    place.getPlace().then(function(response){
                    window.alert(response.data);
                    $scope.status="in1";
                    $scope.places=response.data.data.output;
                    
    },function(response){
                    $scope.status="in2";
                    $scope.error=response.statusText;
                    
    });
                    },function(response){
                                    window.alert("Fail");
                    })
    }

});