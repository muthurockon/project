/**
 * 
 */
var app=angular.module("myApp");
app.factory('place',function($http){
            return{
            	getPlace: function () {

             return $http.get("http://localhost:8080/CSREvent/places")
            }
            };
        
          

    });

app.factory('placeReg',function($http){
	  return{
      	regPlace: function(jsonData)
      	{
      		return $http({

                 method:'POST',

                 url : 'http://localhost:8080/CSREvent/places' ,

                  data:jsonData,

                  headers:{

                          "Content-Type":"application/json"

                  }

          }

  			);
      	}
      }
});


app.factory('deletePlace',function($http)
		{
	  return{
		  getDelPlace: function (placeId) {
         
       return   $http({
           method:'DELETE',
           url:"http://localhost:8080/CSREvent/places/"+placeId
});
      }
      };
  
		});
		