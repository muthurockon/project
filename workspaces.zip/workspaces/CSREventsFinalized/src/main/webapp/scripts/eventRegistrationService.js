/**
 * 
 */
app.factory('insertEvent',function($http){
	  return{
		  setInsertEvent: function(jsonData)
  	{
  		return $http({

             method:'POST',

             url : 'http://localhost:8080/CSREvent/events' ,

              data:jsonData,

              headers:{

                      "Content-Type":"application/json"
                    	
              }

      }

			);
  	}
  }
});

