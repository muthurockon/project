/**
 * 
 */

angular.module("myApp").controller('attCtrl', function($scope,$http,attendenceDetails,dispUser){
                 $scope.viewAttrendence=false;
                 $scope.selectVal=1;
                 $scope.users={};
                 $scope.userDetails={};
                 var attendence=[];
                 console.log("Inside controller");
                 
                 dispUser.getDispUser().then(function(response){
                      console.log("Success message")
                      $scope.users=response.data.data.output;
                      $scope.viewAttrendence=true;
                  },function(response) {
                      window.alert('No users found');
                  });
                      
                 
                 $scope.submitAttendence=function(){
                 	
                 	attendence=[];
                 var k=0;
                 for(var i=0;i<$scope.users.length;i++)
                 	{
                 	
                 	if (document.getElementById($scope.users[i].commitId+'p').checked) {
                 		//$scope.attendence[i]=$scope.users[i].commitId;
                 		attendence.push($scope.users[i].commitId);
                 		$scope.users[i].weeksPending--;
                   	  
                   	}
                 	
                 	}
                 var jdata = JSON.stringify(attendence);
                 window.alert(jdata);
                 attendenceDetails.getAttendence(jdata).then(function(response){
                      
                     $scope.message="Updated Successfully";
                     for(var i=0;i<$scope.users.length;i++)
                  	{
                  	
                  	if (document.getElementById($scope.users[i].commitId+'p').checked) {
                  		//$scope.attendence[i]=$scope.users[i].commitId;
                  		//attendence.push($scope.users[i].commitId);
                  		$scope.users[i].weeksPending--;
                    	  
                    	}
                  	}
                     window.alert('Updated successfully');
                     
                   //  $window.location.href = '/user';
                   // $location.path('/user');
                  },function(response) {
                      window.alert('No users found');
                    
                  });
                 
                 
                
                 }
                 
                 $scope.orderByThis=function(x)
                 {
                 	$scope.order=x;
                 }
                 
 });