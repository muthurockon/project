/**
 * 
 */
var app=angular.module("myApp");

app.factory('editUser',function($http){
	  return{
    	updateUser: function(commitId,jsonData)
    	{
    		return $http({

               method:'PUT',

               url : 'http://localhost:8080/CSREvent/users/'+commitId ,

                data:jsonData,

                headers:{

                        "Content-Type":"application/json"

                }

        }
    	
			);
    	}
    }
});
app.factory('editUserDetails',function($http){
	  return{
		  updateUserDetails: function(commitId,jsonData)
  	{
  		return $http({

             method:'PUT',

             url : 'http://localhost:8080/CSREvent/user-details/'+commitId ,

              data:jsonData,

              headers:{

                      "Content-Type":"application/json"

              }

      }

			);
  	}
  }
});