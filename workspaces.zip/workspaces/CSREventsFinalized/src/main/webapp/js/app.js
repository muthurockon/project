/*var app=angular.module("myApp",['ngRoute']);
 app.config(function ($routeProvider,$locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when('/usersRegistration',{
        templateUrl :"usersRegistration.html"
    })
    .when('/employeePage',{
        templateUrl:'user.html'

    }); 
});*/
            angular.module("myApp").controller('myCtrl',function($scope,$http){
                $scope.view=false;
                console.log("Inside controller");
                $scope.myClick=function(){
                    $scope.view=!$scope.view;
                     $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvent/users'
                   
                 }).success(function(response){
                     console.log("Success message")
                     $scope.users=response.data.output;
                 }).error(function(response) {
                     window.alert('No users found');
                 });
                }
                 $scope.users={};
                 $scope.userDetails={};
                
            });
            app.controller('myCtrlSelectSingle',function($scope,$http,$log){
                $scope.view1=false;
                $scope.access=true;
                 $scope.options=false;
                $scope.users={};
                  $scope.userDetails={};
                console.log("Inside Select single controller");
                $scope.selectOption=function(){
                    $scope.options=!$scope.options;
                }
                $scope.selecrUser=function(){
                    $scope.view1=!$scope.view1;
                     $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvent/users/'+$scope.commitId
                   
                 }).success(function(response){
                     console.log("Success message")
                     $scope.users=response.data.output;
                   
                 }).error(function(response) {
                     window.alert('No users found');
                         $scope.view1=false;
                 });
                 $http({ 
                    method: 'GET',
                    url:'http://localhost:8080/CSREvent/user-details/'+$scope.commitId
                   
                 }).success(function(response){
                     console.log("Success message")
                     $scope.userDetails=response.data.output;
                     console.log($scope.userDetails);
                 }).error(function(response) {
                     window.alert('No users found');
                         $scope.view1=false;
                 });
                        $scope.editing=function()
                        {
                            $scope.access=false;
                            $scope.viewSave=true;

                        }
                        $scope.updating=function()
                        {
                         $scope.access=true;
                         console.log($scope.userDetails[0].personalEmail);
                         var details={
                              phoneNumber   : $scope.userDetails[0].phoneNumber,
                              personalEmail : $scope.userDetails[0].personalEmail,
                              location      : $scope.userDetails[0].location,
                 };
                                var data={
                
                
                deignation: $scope.users[0].deignation,
            
                    
                  };
                            var jdata = JSON.stringify(data);
                        var jdetails=JSON.stringify(details);
                        $http.put('http://localhost:8080/CSREvent/users/'+$scope.commitId, jdata)
                        .success(function(response){
                     
                    $scope.message="updated Successfully";
                 
                 })
                         $http.put('http://localhost:8080/CSREvent/user-details/'+$scope.commitId, jdetails)
                         .success(function(response){
                     
                    $scope.message="Updated Successfully";
                    console.log($scope.message);
                  
                  // $location.path('/user');
                 })
                          $scope.viewSave=false;
                           $scope.selecrUser();
                        }
                        $scope.cancelUpdating=function(){

                         $scope.access=true;
                         $scope.viewSave=false;
                         $scope.selecrUser();
                        }
                
                
                }
                 
                $log.log($scope.users.commitId);
            });


             app.controller('myCtrlDelete',function($scope,$http){
                $scope.view2=false;
                console.log("Inside Delete single controller");
                $scope.deleteUser=function(){
                    $scope.view2=!$scope.view2;
                     $http({ 
                    method: 'DELETE',
                    url:'http://localhost:8080/CSREvent/users/'+$scope.commitIdDel
                   
                 }).success(function(response){
                     console.log("Success message")
                    $scope.message="Deleted Successfully";
                 }).error(function(response) {
                                    $scope.message="No ID Found";
                         $scope.view2=false;
                 });
                         $http({ 
                    method: 'DELETE',
                    url:'http://localhost:8080/CSREvent/user-details/'+$scope.commitIdDel
                   
                 }).success(function(response){
                     console.log("Success message")
                    $scope.message="Deleted Successfully";
                 }).error(function(response) {
                     $scope.message="No ID Found";
                         $scope.view2=false;
                 });
                }
                 $scope.users={};
                
            });
                          